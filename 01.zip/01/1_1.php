<?php
// 1_1.php
phpinfo();
?>
