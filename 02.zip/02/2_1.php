<?php
// 2_1.php
class foo {
  function a() {
    echo "Method foo::a()\n"; 
  }
}
