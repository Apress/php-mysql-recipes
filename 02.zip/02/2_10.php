<?php
// 2_10.php
class foo {
  private $type = null;
  function __construct($type) {
    $this->type = $type;
  }
  function getType() {
    return $this->type;
  }
}
$t = new foo('Book');
echo $t->getType() . "\n";
