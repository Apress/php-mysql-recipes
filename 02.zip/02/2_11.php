<?php
// 2_11.php
class foo {
  static private $value = 6;
  function getValue() {
     return self::$value;
  }
}
echo foo::getValue() . "\n";
$bar = new foo();
echo $bar->getValue() . "\n";
