<?php
// 2_12.php
class foo {
  protected $value = 6;
  function method() {
    echo "foo::method()\n";
  }
}
class bar extends foo {
  function method() {
    parent::method();
    echo "bar::method()\nvalue = {$this->value}\n";
  }
}
$a = new bar();
$a->method();
