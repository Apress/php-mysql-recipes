<?php
// 2_13.php
class foo {
  protected $value = 6;
  function method() {
    echo "foo::method()\n";
  }
}
class bar extends foo {
  function method() {
    foo::method();
    echo "bar::method()\nvalue = {$this->value}\n";
  }
}
$a = new bar();
$a->method();
