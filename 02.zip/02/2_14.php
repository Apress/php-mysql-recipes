<?php
// 2_14.php
class foo {
  private $type = null;
  function __construct($type) {
    $this->type = $type;
  }
}
$t = new foo('Book');
