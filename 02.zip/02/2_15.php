<?php
// 2_15.php
class logger {
  private $fp;
  function __construct($file_name) {
    $this->fp = fopen($file_name, "at");
  }
  function __destruct() {
    $this->log('Log file closed');
    if ($this->fp) {
      fclose($this->fp);
    }
  }
  function log($message) {
    if ($this->fp) {
      $t = date("c");	//ISO 8601 timestamp
      fwrite($this->fp, "{$t} {$message}\n");
    }
  }
}
$logger = new logger('log.txt');
$logger->log('Event');
