<?php
// 2_16.php
class html {
  private $type;
  private $c = '';
  function __construct($type = 'div') {
    $this->type = $type;
  }
  function content($c) {
    $this->c .= $c;
  }
  function __toString() {
    return "<{$this->type}>{$this->c}</{$this->type }>";
  }
}
$div = new html();
$span = new html('span');
$span->content('place some text here');
$div->content($span);
echo $div;
