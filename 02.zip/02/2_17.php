<?php
// 2_17.php
class car {
  private $type;
  private $properties = array();
  
  function __construct($type) {
    $this->type = $type;
  }
  
  function __set($name, $value) {
    switch($name) {
      case 'type' :
        $this->type = $value;
        break;
      case 'wheels' :
        if (in_array($value, array(3,4,6))) {
          $this->properties[$name] = $value;
        }
        else {
          trigger_error(
            "Property wheels must be 3,4 or 6",
            E_USER_NOTICE
          );
        }
        break;
      case 'seats' : 
        if (in_array($value, array(2,4,5,7,8))) {
          $this->properties[$name] = $value;
        }
        else {
          trigger_error(
            "Property seats must be 2,4,5,7 or 8",
            E_USER_NOTICE
          );
        }
        break;
      default :
        $this->properties[$name] = $value;
        break;
    }
  }
  
  function __get($name) {
    if (array_key_exists($name, $this->properties)) {
      return $this->properties[$name];
    }
    else if($name == 'type') {
      return $this->type;
    }
    trigger_error(
      "Undefined property $name",
      E_USER_NOTICE
    );
    return null;
  }
  
  function __isset($name) {
    return array_key_exists($name, $this->properties);
  }
  
  function __undet($name) {
    unset($this->properties[$name]);
  }

  function __toString() {
    $prop = array();
    foreach ($this->properties as $k => $v) {
      $prop[] = "$v $k";
    }
    return "The {$this->type} has " . implode(", ", $prop) . "\n";
  }
}

$c1 = new car('truck');
$c1->wheels = 4;
$c1->seats = 2;
$c1->color = 'white';

$c2 = new car('big truck');
$c2->wheels = 6;
$c2->seats = 5;
$c2->color = 'blue';

echo $c1;
echo $c2;

$c2->seats = 9; // This will trigger a notice.
