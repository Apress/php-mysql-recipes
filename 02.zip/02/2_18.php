<?php
// 2_18.php
class Database {
  protected $pdo;
  private $dsn, $username, $password;
  
  public function __construct($dsn, $username, $password) {
    $this->dsn = $dsn;
    $this->username = $username;
    $this->password = $password;
    $this->connect();
  }
  
  private function connect() {
    $this->pdo = new PDO($this->dsn, $this->username, $this->password);
  }
  
  public function __sleep() {
    return array('dsn', 'username', 'password');
  }
  
  public function __wakeup() {
    $this->connect();
  }
}

$db = new Database('sqlite:mydb', 'user', 'password');

$a = serialize($db);
echo $a;
