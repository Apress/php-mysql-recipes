<?php
// 2_2.php
class foo {
  function a() {
    echo "Method foo::a()\n"; 
  }
}

class bar extends foo {
   function b() {
       echo "Method bar::b()\n"; 
   }
}
