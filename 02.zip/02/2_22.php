<?php
// 2_22.php
class MethodOverload {
  private function call($name, $param, $context) {
    switch ($name) {
      case 'f1' :
      case 'f2' :
        echo "You called $name in $context context\n";
        break;
      default :
        trigger_error("Undefined method '$name'", E_USER_NOTICE);
        break;
    }
  }
  function __call($name, $param) {
    $this->call($name, $param, 'object');
  }
  static function __callStatic($name, $params) {
   self::call($name, $param, 'static');
  }
  static function abc() {
    echo "abc() called\n";
  }
}

$a = new MethodOverload();
$a->f1();

MethodOverload::f2();
MethodOverload::F2();
MethodOverload::ABC();
