<?php
// 2_23.php
class database {
  protected $host;
  protected $user;
  protected $password;
  
  function __construct($host, $user, $password) {
    $this->host = $host;
    $this->user = $user;
    $this->password = $password;
  }
}

$db = new database('localhost', 'user', 'secret');
var_dump($db);

class database2 {
  protected $host;
  protected $user;
  protected $password;
  
  function __construct($host, $user, $password) {
    $this->host = $host;
    $this->user = $user;
    $this->password = $password;
  }
  function __debugInfo() {
    return array(
      'host' => $this->host,
    );
  }
}

$db = new database2('localhost', 'user', 'secret');
var_dump($db);
