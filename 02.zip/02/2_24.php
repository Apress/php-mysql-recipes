<?php
// 2_24.php
$a = [
  'host' => 'localhost',
  'database' => 'mydb',
  'user' => 'user'
];
$o = (object)$a;
echo $o->host;
