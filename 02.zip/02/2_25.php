<?php
// 2_25.php
$a = new stdClass();
$a->host = 'localhost';
