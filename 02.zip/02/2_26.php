<?php
// 2_26.php
$path = "./";

// Open a known directory, and proceed to read its contents
if (is_dir($path)) {
  if ($dh = opendir($path)) {
    while (($file = readdir($dh)) !== false) {
      echo "filename: $file : filetype: " . filetype($path . $file) . "\n";
    }
    closedir($dh);
  }
}
