<?php
// 2_27.php
$path = "./";

// Open a known directory, and proceed to read its contents
if (is_dir($path)) {
  $dir = dir($path);
  while (($file = $dir->read()) !== false) {
    echo "filename: $file : filetype: " . filetype($path . $file) . "\n";
  }
  $dir->close();
}
