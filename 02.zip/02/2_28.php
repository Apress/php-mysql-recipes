<?php
// 2_28.php
$path = "./";

// Open a known directory, and proceed to read its contents
if (is_dir($path)) {
  $dir = new Directory();
  $dir->path = $path;
  $dir->handle = opendir($path);
  while (($file = $dir->read()) !== false) {
    echo "filename: $file : filetype: " . filetype($path . $file) . "\n";
  }
  $dir->close();
}
