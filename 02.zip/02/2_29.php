<?php
// 2_29.php
trait A {
  protected $var;
}

class B {
  use A;
  function Get() {
    return $this->var;
  }
  function Set($var) {
    $this->var = $var;
  }
}
$o = new B();
$o->Set(15);
echo $o->Get();
