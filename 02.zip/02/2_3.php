<?php
// 2_3.php
include "./2_2.php";
$foo = new foo();
$foo->a();

$bar = new bar();
$bar->b();
$bar->a();
