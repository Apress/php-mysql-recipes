<?php
// 2_30.php

trait A {
  protected $var;
  function Get() {
    return $this->var;
  }
  function Set($var) {
    $this->var = $var;
  }
}

class B {
  use A;
}

class C {
  use A;
}

$o = new B();
$o->Set(15);
echo $o->Get();
