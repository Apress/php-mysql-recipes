<?php
// 2_31.php

class A {
  public static $var;
}

class B extends A {}
class C extends A {}

B::$var = 15;
echo B::$var . "\n";
echo C::$var . "\n";
