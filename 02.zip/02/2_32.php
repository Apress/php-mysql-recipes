<?php
// 2_32.php

trait A {
  public static $var;
}

class B {
  use A;
}
class C {
  use A;
}

B::$var = 15;
echo B::$var . "\n";
echo C::$var . "\n";
