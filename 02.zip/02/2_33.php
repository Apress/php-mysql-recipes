<?php
// 2_33.php
trait add {
  function add($a, $b) {
    return $a + $b;
  }
}
trait subtract {
  function subtract($a, $b) {
    return $a - $b;
  }
}
trait math {
  use add, subtract;
}
class calc {
  use add, subtract;
}
class calc2 {
  use math;
}

$o = new calc2();
echo $o->add(4,5) . "\n";
