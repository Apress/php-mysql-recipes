<?php
// 2_34.php
trait A {
  function f1() {}
}
trait B {
  function f1() {}
}
class C {
  use A, B {
    B::f1 insteadof A;
    A::f1 as func1;
  }
}
