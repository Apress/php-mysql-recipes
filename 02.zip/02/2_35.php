<?php
// 2_35.php
namespace Test;

function t1() {
}
