<?php
// 2_36.php
namespace Test\Utilities;

function f1($a) {
  return $a * 2;
}
