<?php
// 2_37.php
namespace Test;
include "2_36.php";

function f1($a) {
  return $a * 3;
}

echo "Relative\n";
echo f1(5) . "\n";
echo Utilities\f1(5) . "\n";

namespace MyProject;

echo "Absolute\n";
echo \Test\f1(5) . "\n";
echo \Test\Utilities\f1(5) . "\n";
