<?php
// 2_38.php 
include "2_36.php";

use Test\Utilities as U;

echo U\f1(3) . "\n";
