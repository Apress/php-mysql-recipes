<?php
// 2_39.php
include "2_36.php";

use function Test\Utilities\f1;

echo f1(3) . "\n";
