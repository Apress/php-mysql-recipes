<?php
// 2_4.php
abstract class MyDB {
  protected $link = null;
  abstract function connect($database, $host = null, $user = null, $password = null);
  abstract function disconnect();
  abstract function query($sql);
  function escape($str) {
    return str_replace("'", "\'", $str);
  }
}

class MySQL extends MyDB {
  function connect($database, $host = null, $user = null, $password = null) {
    $this->link = mysql_connect($host, $user, $password);
    mysql_selectdb($database, $this->link);
  }

  function disconnect() {
    mysql_disconnect($this->link);
    $this->link = null;
  }

  function query($sql) {
    $rs = mysql_query($sql);
  }
}

class sqLite extends MyDB {
  function connect($database, $host = null, $user = null, $password = null) {
    $this->link = sqlite_open($database);
  }

  function disconnect() {
    sqlite_close($this->link);
    $this->link = null;
  }

  function query($sql) {
    $rs = sqlite_query($sql);
  }
}
