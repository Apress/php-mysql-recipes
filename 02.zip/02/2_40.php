<?php
// 2_40.php
function __autoload($class_name) {
  include $class_name . '.php';
}
