<?php
// 2_41.php
function autoload($class) {
  include "../classes/{$class}.inc";
}
spl_autoload_register("autoload");
