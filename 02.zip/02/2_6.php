<?php
// 2_6.php
class foo {
  static function a() {
   echo "Test\n";
  }
}
foo::a();
$foo = new foo();
$foo->a();
