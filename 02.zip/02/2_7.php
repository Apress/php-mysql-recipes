<?php
// 2_7.php
class foo {
  static private $b = 5;
  static function a() {
    foo::$b++;
    echo foo::$b;
  }
}
foo::a();
