<?php
// 2_8.php
class foo {
  $a = 5;
}
$foo = new foo();
$foo->a = 7;
