<?php
// 2_9.php
class foo {
  private $a = 5;
}
$foo = new foo();
$foo->a = 7;
