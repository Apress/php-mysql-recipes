<?php
// 3_1.php
$i = 5;
$j = 5 * $i;
