<?php
// 3_10.php
echo base_convert(~PHP_INT_MAX, 10, 2);
