<?php
// 3_14.php
printf("%b\n", 0b100);
printf("%b\n", ~0b100);
