<?php
// 3_15.php
$v = 0xE;
$x = $v & ~0x8;
