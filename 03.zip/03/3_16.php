<?php
// 3_16.php
$bits = PHP_INT_SIZE * 8;
$v = 1;
for ($i = 0; $i < $bits; $i++) {
  printf("$v << $i = %64b \n", $v << $i);
}
