<?php
// 3_17.php
$bits = PHP_INT_SIZE * 8;
$v = 1;
for ($i = 0; $i < $bits; $i++) {
  $v = $v << 1;
}
$vv = 1 << $bits;
echo  "$v, $vv\n";
