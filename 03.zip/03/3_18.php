<?php
// 3_18.php
$a = -3.2556;
echo abs($a) . "\n";        // 3.2556
echo floor($a) . "\n";      // -4
echo floor(abs($a)) . "\n"; // 3
echo ceil($a) . "\n";       // -3
echo ceil(abs($a)) . "\n";  // 4
echo round($a, 2) . "\n";   // -3.26
