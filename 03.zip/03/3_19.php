<?php
// 3_19.php
$r1 = mt_rand();
$rmax = mt_getrandmax();
$r2 = mt_rand(-5, 5);
echo "$r1\n$rmax\n$r2\n";
