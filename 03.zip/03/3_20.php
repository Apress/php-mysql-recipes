<?php
// 3_20.php
$r = mt_rand(0, 1000);
$v = 1 + $r / 1000;
echo "Random value between 1 and 2 is $v\n";
