<?php
// 3_21.php
$ref = 0.001; 	// 1 mW.
$p = 1.0;		// 1 W
$r = $p / $ref;
$db = 10*log10($r);
echo $db . " dBm\n";
