<?php
// 3_22.php
$principal = 1000;
$interest = 0.05;
$periods = array(1, 2, 4, 12);
foreach ($periods as $p) {
	$ci = $principal * pow(1 + $interest / $p, $p);
	echo "Periods: $p, future value = $ci\n";
}
