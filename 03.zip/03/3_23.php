<?php
// 3_23.php
$interest = 1;
$periods = array(1, 2, 4, 12, 52, 365, 8670, 525600, 31536000);
foreach ($periods as $p) {
	$ci = pow(1 + $interest / $p, $p);
	echo "Periods: $p, future value = $ci\n";
}
