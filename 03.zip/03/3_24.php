<?php
// 3_24.php
define('RADIUS_KM', 6371);
define('RADIUS_MILES', 3959);

function Pos2Distance($pos1, $pos2, $unit = RADIUS_KM, $precision = 0) {
    $lon1 = deg2rad($pos1['lon']);
    $lat1 = deg2rad($pos1['lat']);
    $lon2 = deg2rad($pos2['lon']);
    $lat2 = deg2rad($pos2['lat']);

    $d = acos(sin($lat1)*sin($lat2) + cos($lat1)*cos($lat2)*cos($lon2-$lon1));

    return round($d * $unit, $precision);
}

$p1 = array('lon' => -74.0059, 'lat' => 40.7128);
$p2 = array('lon' => -118.2437, 'lat' => 34.0522);
