<?php
// 3_25.php
function Bearing($pos1, $pos2) {
  $lon1 = deg2rad($pos1['lon']);
  $lat1 = deg2rad($pos1['lat']);
  $lon2 = deg2rad($pos2['lon']);
  $lat2 = deg2rad($pos2['lat']);

  $b = rad2deg(atan2(sin($lon2 - $lon1)*cos($lat2), cos($lat1)*sin($lat2) - sin($lat1)*cos($lat2)*cos($lon2 - $lon1)));

  return $b < 0 ? 360 + $b : $b;
}

$p1 = array('lon' => -74.0059, 'lat' => 40.7128);
$p2 = array('lon' => -118.2437, 'lat' => 34.0522);
