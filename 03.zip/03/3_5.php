<?php
// 3_5.php
$k = pow(2, 10);
