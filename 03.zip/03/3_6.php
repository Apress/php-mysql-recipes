<?php
// 3_6.php
$i = 100;
$b = 0b100;
$o = 0100;
$h = 0x100;
echo $i . "\n";
echo $b . "\n";
echo $o . "\n";
echo $h . "\n";
