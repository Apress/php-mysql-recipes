<?php
// 3_7.php
echo base_convert(100, 2, 10);
