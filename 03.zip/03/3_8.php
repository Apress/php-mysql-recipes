<?php
// 3_8.php
echo base_convert(0b100, 2, 10);
