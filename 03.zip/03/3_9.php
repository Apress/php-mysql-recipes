<?php
// 3_9.php
echo base_convert(PHP_INT_MAX, 10, 2);
