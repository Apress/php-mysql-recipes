<?php
// 4_1.php
$a = array();	// Empty array
$b = [];	// Empty array
$c = array(1, 2, 3, 4, 5);
$d = array(5 => 'Orange', 'Apple', 'Banana', 'test' => 5);
$e = array(
  'host' => 'localhost',
  'database' => 'orders',
  'user' => 'root',
  'password' => 'secret',
);
$f = [
  'host' => 'localhost',
  'database' => 'orders',
  'user' => 'root',
  'password' => 'secret',
];
