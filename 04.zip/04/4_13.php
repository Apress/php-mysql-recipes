<?php
// 4_13.php
$con = mysqli_connect("127.0.0.1", "root", "secret", "book");
$rs = mysqli_query($con, "select * from person");
if ($rs) {
  $persons = array();
  while($row = mysqli_fetch_assoc($rs)) {
    $persons[] = $row;
  }
  mysqli_free_result($rs);
}
mysqli_close($con);

for ($i = 0; $i < sizeof($persons); $i++) {
  echo "{$persons[$i]['first_name']} {$persons[$i]['last_name']} " .
    gmdate("M j Y", $persons[$i]['date_of_birth']) . "\n";
}
