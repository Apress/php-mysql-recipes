<?php
// 4_16.php
$fruit = array('pear', 'apple', 'orange', 'banana', 'kiwi');
sort($fruit);
print_r($fruit);
rsort($fruit);
print_r($fruit);
