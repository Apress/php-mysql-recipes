<?php
// 4_17.php
$fruit = array('pear', 'apple', 'Orange', 'Banana', 'kiwi');
sort($fruit);
print_r($fruit);
sort($fruit, SORT_FLAG_CASE | SORT_STRING);
print_r($fruit);
