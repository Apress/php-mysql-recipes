<?php
// 4_18.php
$items = array('item1', 'Item11', 'Item12', 'item2', 'item20', 'item21');
sort($items);
print_r($items);
sort($items, SORT_FLAG_CASE | SORT_NATURAL | SORT_STRING);
print_r($items);
