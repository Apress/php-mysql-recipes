<?php
// 4_19.php
$fruit = array('pear' => 10, 'apple' => 3, 'orange' => 15, 'banana' => 5, 'kiwi' => 2);
sort($fruit);
print_r($fruit);

$fruit = array('pear' => 10, 'apple' => 3, 'orange' => 15, 'banana' => 5, 'kiwi' => 2);
asort($fruit);
print_r($fruit);
