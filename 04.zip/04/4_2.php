<?php
// 4_2.php
$a = [1, 2, 5=>3, 4, 5, 10 => 6];
echo "\$a contains\n";
foreach($a as $k => $v) {
  echo "$k = $v\n";
}

$b = [5 => 5, 4 => 4, 3 => 3, 2 => 2];
echo "\$b contains\n";
foreach($b as $k => $v) {
  echo "$k = $v\n";
}
