<?php
// 4_20.php
$fruit = array('pear' => 10, 'apple' => 3, 'orange' => 15, 'banana' => 5, 'kiwi' => 2);
ksort($fruit);
print_r($fruit);
