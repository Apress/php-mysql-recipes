<?php
// 4_21.php
$con = mysqli_connect("127.0.0.1", "root", "Wbp2Theworld", "book");
$rs = mysqli_query($con, "select * from person");
if ($rs) {
  $persons = array();
  while($row = mysqli_fetch_assoc($rs)) {
    $persons[] = $row;
  }
  mysqli_free_result($rs);
}
mysqli_close($con);
sort($persons);
print_r($persons);
