<?php
// 4_23.php

function SortFirstName($a, $b) {
  if ($a['first_name'] == $b['first_name']) {
    return 0;
  }
  elseif ($a['first_name'] > $b['first_name']) {
    return 1;
  }
  else {
   return -1;
  }
}

function SortLastName($a, $b) {
  if ($a['last_name'] == $b['last_name']) {
    return 0;
  }
  elseif ($a['last_name'] > $b['last_name']) {
    return 1;
  }
  else {
   return -1;
  }
}

function SortDOB($a, $b) {
  if ($a['date_of_birth'] == $b['date_of_birth']) {
    return 0;
  }
  elseif ($a['date_of_birth'] > $b['date_of_birth']) {
    return 1;
  }
  else {
   return -1;
  }
}
$con = mysqli_connect("127.0.0.1", "root", "Wbp2Theworld", "book");
$rs = mysqli_query($con, "select * from person");
if ($rs) {
  $persons = array();
  while($row = mysqli_fetch_assoc($rs)) {
    $persons[] = $row;
  }
  mysqli_free_result($rs);
}
mysqli_close($con);
usort($persons, 'SortFirstName');
print_r($persons);
usort($persons, 'SortLastName');
print_r($persons);
usort($persons, 'SortDOB');
print_r($persons);
