<?php
// 4_25.php
$stack = array();
array_unshift($stack, 'orange');
array_unshift($stack, 'apple');
array_unshift($stack, 'banana');
print_r($stack);
$fruit = array_shift($stack);
print_r($stack);
