<?php
// 4_27.php
$a = array(
  'apple', 
  'orange', 
  'banana', 
  'animal' => 'horse', 
  'vechicle' => 'truck'
);
$b = array(
  'kiwi',
  'grape'
);

// Remove all but two elements from the array
$a1 = $a;
$r = array_splice($a1, 2, 2);
print_r($r);
print_r($a1);

// instert $b into $a
$a1 = $a;
$r = array_splice($a1, 2, 0, $b);
print_r($r);
print_r($a1);

// remove one element and inster $b
$a1 = $a;
$r = array_splice($a1, 2, 1, $b);
print_r($r);
print_r($a1);
