<?php
// 4_28.php
$a = array(
  'apple', 
  'orange', 
  'banana', 
  'animal' => 'horse', 
  'vechicle' => 'truck'
);
print_r($a);
var_dump($a);
var_export($a);
