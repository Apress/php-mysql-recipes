<?php
// 4_3.php
$a = array();
for ($i = 1; $i < 10; $i++) {
  $a[] = $i;
}
print_r($a);
