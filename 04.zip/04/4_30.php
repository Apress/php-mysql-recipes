<?php
// 4_30.php
$a = array(
  'apple',
  'orange',
  'banana',
  'animal' => 'horse',
  'vechicle' => 'truck'
);
file_put_contents('serialize.dat', serialize($a));
