<?php
// 4_31.php
$a = unserialize(file_get_contents('serialize.dat'));
print_r($a);
