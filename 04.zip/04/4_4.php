<?php
// 4_4.php
$a = array();
for ($i = 1; $i < 10; $i++) {
  $a[$i] = $i;
}
print_r($a);
