<?php
// 4_5.php
$a = array(1 => 15, 10 => 20);
for ($i = 1; $i < 10; $i++) {
  $a[$i] = $i;
}
print_r($a);
