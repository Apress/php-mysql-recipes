<?php
// 4_6.php
$a = range(1, 9);
print_r($a);
