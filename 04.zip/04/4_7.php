<?php
// 4_7.php
$a = range(1, 9);
unset($a[4]);
print_r($a);
