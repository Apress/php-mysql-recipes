<?php
// 5_1.php
$ts = time();
echo date("Y m d H:i:s", $ts) . "\n";
date_default_timezone_set("UTC");
echo date("Y m d H:i:s", $ts) . "\n";
