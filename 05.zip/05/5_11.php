<?php
// 5_11.php
        
$gmt_mtime = gmdate('D, d M Y H:i:s', $last_modified) . ' GMT';
$gmt_etime = gmdate('D, d M Y H:i:s', time() + $ttl) . ' GMT'; 

header("Pragma: Cache");
header("Cache-Control: max-age=0, must-revalidate");
header("Last-Modified: " . $gmt_mtime);
header("Expires: " . $gmt_etime);

if (!empty($_SERVER['HTTP_IF_MODIFIED_SINCE']) &&
   $_SERVER['HTTP_IF_MODIFIED_SINCE'] == $gmt_mtime) {
  http_response_code(304);
  exit();
}   
// Output the rest of the response
