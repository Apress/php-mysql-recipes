<?php
// 5_12.php

$ts = time();
echo date("Y-W", $ts) . "\n";
