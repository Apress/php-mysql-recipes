<?php
// 5_13.php

$d = new DateTime();
echo $d->format("M d Y h:i:s a") . "\n";
