<?php
// 5_14.php

$d = new DateTime("2010-10-31 13:15:00");
echo $d->format("M d Y h:i:s a P") . "\n";
