<?php
// 5_15.php

$tz = new DateTimeZone("Europe/Copenhagen");
$d = new DateTime("2010-10-31 13:15:00", $tz);
echo $d->format("M d Y h:i:s a P") . "\n";
