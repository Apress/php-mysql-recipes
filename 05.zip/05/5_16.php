<?php
// 5_16.php

$d = new DateTime();
echo $d->format("M d Y h:i:s a P") . "\n";

// Noon in 2 months
$d = new DateTime("+2 months 12:00");
echo $d->format("M d Y h:i:s a P") . "\n";
