<?php
// 5_18.php
date_default_timezone_set('America/Los_Angeles');
$d = new DateTime("Oct 10 1980");
echo $d->format("M d Y h:i:s a P") . "\n";

$i = new DateInterval('P2Y3M5DT10H');
$d->add($i);
echo $d->format("M d Y h:i:s a P") . "\n";
