<?php
// 5_19.php
// User 1 creates a date
$d1 = new DateTime("Oct 10 1980");
$d2 = new DateTime("March 15 1990");

$i = $d1->diff($d2);

echo $i->format("%Y %M %D %H:%I:%S") . "\n";
