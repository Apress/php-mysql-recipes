<?php
// 5_20.php
// User 1 creates a date
$tz = new DateTimeZone("Europe/Copenhagen");
$d = new DateTime("Oct 10 1980", $tz);
echo $d->format("M d Y h:i:s a P") . "\n";

// User 2 in Los Angeles
$tz = new DateTimeZone("America/Los_Angeles");
$d->setTimezone($tz);
echo $d->format("M d Y h:i:s a P") . "\n";
