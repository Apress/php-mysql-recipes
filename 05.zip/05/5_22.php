<?php
// 5_22.php

$now = time();
$dates = [];

for ($i = 0; $i<100; $i++) {
  $dates[] = mt_rand(0, $now);
}
$con = mysqli_connect("127.0.0.1", "root", "secret", "book");
$rs = mysqli_query($con, "select * from date_time");
while ($row = mysqli_fetch_row($rs)) {
  $dates[] = strtotime($row[0]);
}
mysqli_free_result($rs);
mysqli_close($con);
print_r($dates);
