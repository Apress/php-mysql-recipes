<?php
// 5_24.php

date_default_timezone_set("America/Los_Angeles");
// calculate 3 weeks from current time
$ts = strtotime("+3 weeks");
echo date("Y/m/d h:i:s a", $ts) . "\n";

// calculate 5 days back from current time
$ts = strtotime("-5 days");
echo date("Y/m/d h:i:s a", $ts) . "\n";

// calculate a timestamp at 11:30 3 month after a given date
$ref = mktime(0, 0, 0, 12, 15, 2012);
$ts = strtotime("11:30 + 3 month", $ref);
echo date("Y/m/d h:i:s a", $ts) . "\n";
