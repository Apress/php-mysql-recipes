<?php
// 5_6.php
$ts = time();

echo date("l F d Y h:i:s a", $ts) ."\n";
