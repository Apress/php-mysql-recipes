<?php
// 5_7.php
$ts = time();

echo strftime("%A %B %e %Y %I:%M:%S %P ", $ts) ."\n";
