<?php
// 6_1.php
$t1 = "7:00 am";
$t2 = "11:00 am";

echo str_pad($t1, 8, '0', STR_PAD_LEFT) . "\n";
echo str_pad($t2, 8, '0', STR_PAD_LEFT) . "\n";
