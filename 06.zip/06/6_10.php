<?php
// 6_10.php
printf("String = %s\n", <<<HEREDOC
This is a very long string
HEREDOC
);
