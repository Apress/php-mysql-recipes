<?php
// 6_11.php
$con = mysqli_connect("127.0.0.1", "root", "secret", "book");
$rs = mysqli_query($con, "select * from person");
if ($rs) {
  $persons = array();
  while($row = mysqli_fetch_assoc($rs)) {
    $persons[] = $row;
  }
  mysqli_free_result($rs);
}
mysqli_close($con);

$person_tpl = <<<HEREDOC
<div>
  <span>%first_name%</span>
  <span>%last_name%</span>
  <span>%date_of_birth%</span>
</div>
HEREDOC;

$section_tpl = <<<HEREDOC
<div>%persons%</div>
HEREDOC;

$html = "";
$p = array();
foreach ($persons as $person) {
  $r = str_replace('%first_name%', $person['first_name'], $person_tpl);
  $r = str_replace('%last_name%', $person['last_name'], $r);
  $r = str_replace('%date_of_birth%', 
       gmdate("M j Y", $person['date_of_birth']), $r);
  $p[] = $r;
}

echo str_replace('%persons%', implode('', $p), $section_tpl);
