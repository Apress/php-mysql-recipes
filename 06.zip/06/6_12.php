<?php
// 6_12.php
$con = mysqli_connect("127.0.0.1", "root", "secret", "book");

// create table strings (
//   val  varchar(250);
// );

$name = "Mark O'Brian";
// This will fail
mysqli_query($con, "insert into strings (val) values ('{$name}');");

$name = mysqli_escape_string($con, $name);
// This will succeed
mysqli_query($con, "insert into strings (val) values ('{$name}');");
