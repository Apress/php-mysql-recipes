<?php
// 6_13.php
$con = mysqli_connect("127.0.0.1", "root", "secret", "book");

// create table strings (
//   val  varchar(250);
// );

$name = "My Name";
// This will fail
mysqli_query($con, "insert into strings (val) values ('{$name}');");
