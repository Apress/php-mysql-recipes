<?php
// 6_14.php

$content = file_get_contents('file.txt');
$a = explode("\n", $content);

foreach ($a as $line) {
  // Do something
}
