<?php
// 6_15.php

$a = [1, 5, 7, 9, 3, 4];

$s = implode(',', $a);

$sql = "select * form mytable where id in({$s})"
