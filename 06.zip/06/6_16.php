<?php
// 6_16.php

$con = mysqli_connect('127.0.0.1', 'root', 'secret', 'book');

$q = mysqli_escape_string($con, trim($_POST['name']));

$sql = "select * form person where name like '%{$q}%'";
