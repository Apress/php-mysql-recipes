<?php
// 6_17.php

$s = "Lorem ipsum dolor sit amet, has dicit eleifend no, legimus " .
     "voluptatibus ad mei. Ornatus sententiae vituperatoribus mel ea, " .
     "at veri maiorum quaerendum vel, vis at deleniti vulputate. An vis " .
     "quis percipitur reformidans. Eu agam tation vel, " .
     "pri nemore discere no.";

$p_first = strpos($s, 'at');
$p_last = strrpos($s, 'at');

echo "'at' is first found at positionn {$p_first}\n";
echo "'at' is last found at positionn {$p_last}\n";

$p = strchr($s, 'at');
echo "{$p}\n";

$p = strrchr($s, 'at');
echo "{$p}\n";
