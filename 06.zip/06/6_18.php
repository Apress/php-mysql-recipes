<?php
// 6_18.php

$s = "Lorem ipsum dolor sit amet, has dicit eleifend no, legimus " .
     "voluptatibus ad mei. Ornatus sententiae vituperatoribus mel ea, " .
     "at veri maiorum quaerendum vel, vis at deleniti vulputate. An vis " .
     "quis percipitur reformidans. Eu agam tation vel, " .
     "pri nemore discere no.";

$p_first = strpos($s, 'at');
$p_last = strrpos($s, 'at');

echo substr($s, $p_first + 2, $p_last - $p_first - 2) . "\n";
