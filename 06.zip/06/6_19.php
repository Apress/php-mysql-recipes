<?php
// 6_19.php

$filename = "myfile.txt";
$ext = substr($filename, -3);

echo "Extension = {$ext}\n";
