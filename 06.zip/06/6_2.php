<?php
// 6_2.php
$s = str_repeat('abc', 15);
echo $s . "\n";
