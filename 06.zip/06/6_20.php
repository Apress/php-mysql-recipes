<?php
// 6_20.php

$filename = "myfile.txt";
$p = strrpos($filename, '.');
$ext = substr($filename, $p + 1);

echo "Extension = {$ext}\n";
