<?php
// 6_21.php

function GetExtension($filename) {
  $ext = null;
  $p = strrpos($filename, '.');
  if ($p !== false) {
    $ext = substr($filename, $p + 1);
  }
  return $ext;
}

$filename = "myfile.txt";
echo "Extension of {$filename} is " . GetExtension($filename) . "\n";

$filename = "myfile.info";
echo "Extension of {$filename} is " . GetExtension($filename) . "\n";

$filename = "myfile";
echo "Extension of {$filename} is " . GetExtension($filename) . "\n";

$filename = ".cvsignore";
echo "Extension of {$filename} is " . GetExtension($filename) . "\n";
