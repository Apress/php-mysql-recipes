<?php
// 6_22.php

$input = 'This is my comment <img src="https://example.com/image.jpg" />';

echo htmlentities($input);
