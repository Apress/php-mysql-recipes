<?php
// 6_23.php

$input = <<<HEREDOC
Comment
<script src="https://example.com/script.js"></script>
<script>
MyFunction();
</script>
<img src="https://example.com/image.jpg" />
This is my opinion about that!
HEREDOC;

$i = strip_tags($input);

echo $i;
