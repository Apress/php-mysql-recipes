<?php
// 6_24.php

// create table files (
//   id int auto_increment,
//   hash varchar(255),
//   filename varchar(255),
//   primary key(id)
// );
// create index ixHash on files(hash);

$con = mysqli_connect('127.0.0.1', 'root', 'secret', 'book');

function GetFile($hash) {
  global $con;
  $file = null;

  $sql = "select * from files where hash = '{$hash}'";
  $rs = mysqli_query($con, $sql);
  if ($rs) {
    $file = mysqli_fetch_row($rs);
    mysqli_free_result($rs);
  }
  return $file;
}

function SaveFile($filename) {
  global $con;
  $hash = hash_file('sha256', $filename);
  if (!GetFile($hash)) {
    mysqli_query($con, "insert into files (hash, filename) values ('{$hash}', '{$filename}')");
  }
}

SaveFile('6_1.php');
SaveFile('6_12.php');
SaveFile('6_1.php');

$rs = mysqli_query($con, "select * from files");
if ($rs) {
  while ($row = mysqli_fetch_row($rs)) {
    print_r($row);
  }
  mysqli_free_result($rs);
}
mysqli_close($con);
