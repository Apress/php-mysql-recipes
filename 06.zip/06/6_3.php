<?php
// 6_3.php
$s = "The sun is up @ 7am";
$s[16] = '6';
echo $s . "\n";
