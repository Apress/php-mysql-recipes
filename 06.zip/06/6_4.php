<?php
// 6_4.php
$s = "The sun is up @ 7am";
$s .= " and it sets again at 7pm";
echo $s . "\n";
