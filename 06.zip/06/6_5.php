<?php
// 6_5.php
$s = "'<h1>Document Title</h1>";
echo str_replace("h1", "h2", $s) . "\n";
