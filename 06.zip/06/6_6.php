<?php
// 6_6.php
$s = "'<H1>Document Title is h1</h1>";
echo str_ireplace("h1>", "h2>", $s) . "\n";
