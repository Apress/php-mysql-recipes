<?php
// 6_7.php
// defining a Heredoc block
$h = <<<HEREDOC
Some string
value
HEREDOC;
