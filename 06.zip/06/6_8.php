<?php
// 6_8.php
// defining a Newedoc block
$n = <<<'NEWDOC'
A different
string value
NEWDOC;
