<?php
// 6_9.php
$a = [
  <<<HEREDOC
Some string
value
HEREDOC
,
  <<<HEREDOC
Second string
HEREDOC
,
];
print_r($a);