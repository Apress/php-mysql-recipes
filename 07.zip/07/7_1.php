<?php
// 7_1.php

class Test {
  protected $a = null;
  function __construct($a) {
    $this->a = $a;
  }
}
