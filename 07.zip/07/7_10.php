<?php
// 7_10.php

function DeleteCache($name) {
  if (file_exists($name)) {
    unlink($file);
  }
}

DeleteCache('cache.html');
