<?php
// 7_11.php

date_default_timezone_set("America/Los_Angeles");
clearstatcache();
$file = "7_11.php";

echo "File Size: " . filesize($file) . "\n";
echo "Created  : " . date("Y-m-d H:i:s", filectime($file)) . "\n";
echo "Modified : " . date("Y-m-d H:i:s", filemtime($file)) . "\n";
echo "Accessed : " . date("Y-m-d H:i:s", fileatime($file)) . "\n";
