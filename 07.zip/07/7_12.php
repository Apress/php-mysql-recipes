<?php
// 7_12.php

date_default_timezone_set("America/Los_Angeles");
clearstatcache();
$file = "7_11.php";

$stat = stat($file);
print_r($stat);
