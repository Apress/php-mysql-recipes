<?php
// 7_13.php

file_put_contents('private.txt', 'The content of this file is private');
chmod('private.txt, 0600);
