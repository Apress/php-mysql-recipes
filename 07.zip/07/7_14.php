<?php
// 7_14.php

// Perform some access control here
$token = sha1(random_bytes(50));
link('../data/bigfile.tgz', $token);
header("Location: $token);
