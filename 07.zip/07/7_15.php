<?php
// 7_15.php

// Perform access control here
header("X-Sendfile: ../data/some_file.tgz");
