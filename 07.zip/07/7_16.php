<?php
// 7_16.php

// Perform access control here
header("X-Accel-Redirect: ../data/some_file.tgz");
