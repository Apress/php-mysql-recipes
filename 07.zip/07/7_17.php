 <?php
// 7_17.php

// Perform access control here
if (stristr($_SERVER["SERVER_SOFTWARE"], 'nginx')) {
  header("X-Accel-Redirect: ../data/some_file.tgz");
else if (stristr($_SERVER["SERVER_SOFTWARE"], 'apache')) {
  header("X-Sendfile: ../data/some_file.tgz");
}
