<?php
// 7_18.php

// Perform access control here
mkdir('MyFiolder', 0700);
