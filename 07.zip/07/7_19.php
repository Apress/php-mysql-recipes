<?php
// 7_19.php

// Perform access control here
mkdir('path/to/MyFiolder', 0700, true);
