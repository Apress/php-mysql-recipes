<?php
// 7_2.php

require "7_1.php";

class Test2 extends Test {
  function SetValue($a) {
    $this->a = $a;
  }

  function GetValue() {
    return $this->a;
  }
}

$t = new Test2(15);
echo $t->GetValue() . "\n";

$t->SetValue(30);
echo $t->GetValue() . "\n";
