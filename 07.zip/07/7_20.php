<?php
// 7_20.php

$data = [
  ['orange', 10],
  ['blood orange', 10],
  ['apple', 25],
  ['pineapple', 1]
];
$fp = fopen('fruits.csv', 'wt');
if ($fp) {
  foreach($data as $fruit) {
    fputcsv($fp, $fruit);
  }
  fclose($fp);
}
