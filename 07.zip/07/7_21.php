<?php
// 7_21.php

$data = [
  ['orange', 10],
  ['blood orange', 10],
  ['apple', 25],
  ['pineapple', 1]
];
$fp = fopen('fruits.tsv', 'wt');
if ($fp) {
  foreach($data as $fruit) {
    fputcsv($fp, $fruit, "\t");
  }
  fclose($fp);
}
