<?php
// 7_22.php

$data = [];
$fp = fopen('fruits.csv', 'rt');
if ($fp) {
  while ($row = fgetcsv($fp, 25)) {
    $data[] = $row;
  }
  fclose($fp);
}
print_r($data);
