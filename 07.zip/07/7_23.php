<?php
// 7_23.php

$html = file_get_contents("http://google.com");
echo $html;
