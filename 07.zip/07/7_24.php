<?php
// 7_24.php

$data = json_decode(file_get_contents("http://jsonip.com"));
print_r($data);
