<?php
// 7_25.php

function http_build_form($mime_boundary, $data) {
  $eol = "\r\n";
  $form_data = '';
  if (is_array($data)) {
    foreach ($data as $name => $value) {
      if (is_array($value)) {
        foreach($value as $val) {
          $form_data .= '--' . $mime_boundary . $eol .
          "Content-Disposition: form-data; name=\"{$name}[]\"" . 
            $eol . $eol . $val . $eol;
        }
      }
      else {
        $form_data .= '--' . $mime_boundary . $eol .
        "Content-Disposition: form-data; name=\"{$name}\"" . 
          $eol . $eol . $value . $eol;
      }
    }
  }
  $form_data .= "--" . $mime_boundary . "--" . $eol . $eol;
  return $form_data;
}

$data = [
  'name' => 'Donald Duck',
  'phone' => '555 555 1234'	
];

$url = http://example.com/form;
$mime_boundary = md5(time());
$content = http_build_form($mime_boundary, $data);

$options = array('http' =>
  array(
    'method'  => 'POST',
    'header'  => 'Content-Type: multipart/form-data; boundary=' .
                 $mime_boundary,
    'content' => $content
  )
);
$context = stream_context_create($options);
$response = file_get_contents($url, FILE_TEXT, $context);
var_dump($response);
