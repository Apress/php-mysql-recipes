<?php
// 7_26.php

$pattern = "*";

$files = glob($pattern);
foreach ($files as $file) {
    echo $file;
    if (is_dir($file)) {
        echo "/";
    }
    echo "\n";
}
