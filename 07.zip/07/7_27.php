<?php
// 7_27.php

$dir = dir(".");
while (($file = $dir->read()) !== false) {
  echo $file;
  if (is_dir($file)) {
    echo "/";
  }
  echo "\n";
}
$dir->close();
