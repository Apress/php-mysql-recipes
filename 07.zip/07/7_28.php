<?php
// 7_28.php

foreach (new DirectoryIterator('.') as $fileInfo) {
    if ($fileInfo->isDot()) continue;
    echo $fileInfo->getFilename();
    if ($fileInfo->isDir()) {
        echo "/";
    }
    echo "\n";
}
