<?php
// 7_29.php

$iterator = new RecursiveDirectoryIterator('.',
  FilesystemIterator::CURRENT_AS_FILEINFO);
foreach (new RecursiveIteratorIterator($iterator) as $fileInfo) {
  if ($fileInfo->isDot()) continue;
  echo $fileInfo->getPathname();
  if ($fileInfo->isDir()) {
    echo "/";
  }
  echo "\n";
}
