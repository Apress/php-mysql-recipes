<?php
// 7_3.php

$f = '';
$fp = fopen('myfile.txt', 'r');
if ($fp) {
  while ($s = fread($fp, 100)) {
    $f .= $s;
  }
  fclose($fp);
}
var_dump($f);
