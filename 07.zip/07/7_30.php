<?php
// 7_30.php

header("Content-Type: image/gif; Content-Disposition: attachment;");
readfile('myfile.gif');
