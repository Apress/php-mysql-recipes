<?php
// 7_31.php

ini_set("zlib.output_compression", "Off");

$files = glob('.');
if (!empty($files)) {
  $zip = new ZipArchive();
  $tmp_name = tempnam("/tmp", "zipfile");
  $res = $zip->open($tmp_name . ".zip", ZipArchive::CREATE);
  if ($res === true) {
    foreach($files as $file) {
      if (is_file($file) || is_link($file)) {
        $zip->addFile($file);
      }
    }
    $zip->close();
    if (file_exists($tmp_name . ".zip")) {
      $file_name = 'archive.zip';
      $file_size = filesize($tmp_name . ".zip");
      header('Content-Type: application/octet-stream; Content-Disposition: attachment');
      readfile($tmp_name . ".zip");
      unlink($tmp_name . ".zip");
      unlink($tmp_name);
    }
  }
}
