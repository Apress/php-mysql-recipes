<?php
// 7_32.php

// This script es expecting a a POST request from a form with at
// least one input
// <input type="file" name="file" />

// This will generate the followng values in the $_FILES superglobal
// $_FILES['file']['error']
// $_FILES['file']['name']
// $_FILES['file']['tmp_name']
// $_FILES['file']['type']
// $_FILES['file']['size']

// Get the file extension from a file name
function GetExtension($file_name) {
	$arrParts = explode(".", $file_name);
	if (sizeof($arrParts) > 1) {
		return strtolower(end($arrParts));
	}
	else {
		return null;
	}
}

$res = false;
$ext = GetExtension($_FILES['file']['name']);
if ($ext == "zip") {
	$zip = new ZipArchive();
	$res = $zip->open($_FILES['file']['tmp_name']);
}
if ($res === true) {
	$zip->extractTo('folder');
	$zip->close();
}
