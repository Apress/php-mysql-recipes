<?php
// 7_4.php

$f = file_get_contents('myfile.html');
echo $f;
