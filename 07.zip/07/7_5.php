<?php
// 7_5.php

$f = '';
$fp = fopen('myfile.txt', 'at');
if ($fp) {
  fwrite($fp, "The text that goes into this file\nAnd some on line 2");
  fclose($fp);
}
