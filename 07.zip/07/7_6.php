<?php
// 7_6.php

$msg = date("Ymd H:i:s ") . "Script started\n";
file_put_contents('myfile.log', $msg, FILE_APPEND);
