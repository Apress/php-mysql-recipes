<?php
// 7_7.php

copy('myfile.log', 'myfile.log.1');
