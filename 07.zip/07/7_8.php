<?php
// 7_8.php

copy('../config/config.php.tmpl', 'config.php');
