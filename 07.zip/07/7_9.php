<?php
// 7_9.php

rename('../config/config.php.tmpl', 'config.php');
