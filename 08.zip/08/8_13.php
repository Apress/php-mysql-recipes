<?php
// 8_13.php

$img = ImageCreateTrueColor(50, 50);
ImageFill($img, 0, 0, 0xffffff);
$sx = mt_rand(0, 49);
$sy = mt_rand(0, 49);

for ($i = 0; $i < 3; $i++) {
  $x = mt_rand(0, 49);
  $y = mt_rand(0, 49);
  ImageLine($img, $sx, $sy, $x, $y, 0);
  $sx = $x;
  $sy = $y;
}
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
