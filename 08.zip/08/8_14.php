<?php
// 8_14.php

$img = ImageCreateTrueColor(100, 50);
ImageFill($img, 0, 0, 0xffffff);
ImageLine($img, 0, 49, 49, 0, 0);
ImageAntialias($img, true);
ImageLine($img, 49, 49, 99, 0, 0);

$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img); 
