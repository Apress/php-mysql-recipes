<?php
// 8_15.php

$img = ImageCreateTrueColor(50, 50);
ImageFill($img, 0, 0, 0xffffff);
$x1 = mt_rand(0, 49);
$y1 = mt_rand(0, 49);
$x2 = mt_rand(0, 49);
$y2 = mt_rand(0, 49);
ImageRectangle($img, $x1, $y1, $x2, $y2, 0xFF0000);
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
