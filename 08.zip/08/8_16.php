<?php
// 8_16.php

$img = ImageCreateTrueColor(50, 50);
ImageFill($img, 0, 0, 0xffffff);
$x1 = 1; $y1 = 1; $x2 = 35;$y2 = 35;
ImageRectangle($img, $x1, $y1, $x2, $y2, 0xFF0000);
$x1 = 15; $y1 = 15; $x2 = 48;$y2 = 48;
ImageRectangle($img, $x1, $y1, $x2, $y2, 0xFF0000);
ImageFillToBorder($img, 16, 16, 0xFF0000, 0x00FFFF);
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
