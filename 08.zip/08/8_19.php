<?php
// 8_19.php

$img = ImageCreateTrueColor(50, 50);
ImageFill($img, 0, 0, 0xffffff);
$points = [
  10, 10,
  45, 5,
  25, 25,
  45, 45,
  10, 40
];
ImagePolygon($img, $points, sizeof($points) / 2,  0xFF0000);
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
