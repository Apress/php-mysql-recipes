<?php
// 8_2.php

$orig = GetImageSize('IMG_0099.JPG');
print_r($orig);
