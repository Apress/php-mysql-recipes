<?php
// 8_20.php

$img = ImageCreateTrueColor(50, 50);
ImageFill($img, 0, 0, 0xffffff);
ImageColorTransparent($img, 0);
ImageLine($img, 10, 10, 40, 10, 0xFF0000);
ImageLine($img, 10, 30, 40, 30, 0);
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
