<?php
// 8_21.php

$img = ImageCreateTrueColor(250, 50);
ImageFill($img, 0, 0, 0xffffff);
ImageString($img, 4, 10, 10, "PHP Recipes", 0);
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
