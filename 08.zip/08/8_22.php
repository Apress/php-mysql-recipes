<?php
// 8_22.php

$img = ImageCreateTrueColor(250, 50);
ImageFill($img, 0, 0, 0xffffff);
ImageTTFText($img, 12, -10, 10, 10, 0, "Verdana.ttf", "PHP Recipes");
$f = $_GET['f'] ?: 'gif';
switch (strtolower($f)) {
  case 'jpg' :
  case 'jpeg' :
    header('Content-Type: image/jpeg');
    ImageJPEG($img);
    break;
  case 'png' :
    header('Content-Type: image/png');
    ImagePNG($img);
    break;
  default :
    header('Content-Type: image/gif');
    ImageGIF($img);
    break;
}
ImageDestroy($img);
