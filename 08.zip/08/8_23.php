<?php
// 8_23.php

$file = $_REQUEST['file'] ?: 'IMG_0099.JPG';
$max_width = $_REQUEST['w'] ?: 600;

if (file_exists($file)) {
  $orig = GetImageSize($file);
  header('Content-Type: ' . $orig['mime']);
  header('Content-Disposition: inline;  filename="'. $file . '"');

  if (!file_exists("_" . $file)) {
    if ($orig[0] > $max_width) {
      $src = ImageCreateFromJpeg($file);
      $img = ImageScale($src, $max_width);
      ImageDestroy($src);
      $orig[0] = ImageSX($img);
      $orig[1] = ImageSY($img);
    }
    else {
      $img = ImageCreateFromJpeg($file);
    }
    $wm = GetImageSize('watermark.png');
    $watermark = ImageCreateFromPng('watermark.png');
    if ($orig[0] > $wm[0]) {
      $width = $wm[0];
      $height = $wm[1];
      $x = ($orig[0] - $wm[0]) / 2;
      $y = ($orig[1] - $wm[1]) / 2;
    }
    else {
      $d = $orig[0] / $wm[0];
      $width = $orig[0];
      $height = $wm[1] * $d;
      $x = 0;
      $y = ($orig[1] - $height) / 2;
    }
    ImageCopyResampled($img, $watermark, $x, $y, 0, 0, 
                       $width, $height, $wm[0], $wm[1]);
    switch ($orig[2]) {
      case IMG_JPG :
      case IMG_JPEG :
        ImageJPEG($img, '_' . $file);
        break;
      case IMG_PNG :
        ImagePNG($img, '_' . $file);
        break;
      case IMG_GIF :
        ImageGIF($img, '_' . $file);
        break;
    }
    ImageDestroy($watermark);
    ImageDestroy($img);
  }
  readfile("_" . $file);
}
