<?php
// 8_5.php

$size = [150, 150];
$orig = GetImageSize('IMG_0099.JPG');

$a1 = $orig[0] / $size[0];
$a2 = $orig[1] / $size[1];

if ($a1 < $a2) {
  $width = $size[0] * $a1;
  $height = $size[1] * $a1;
  $x = 0;
  $y = ($orig[1] - $height) / 2;
}
else {
  $width = $size[0] * $a2;
  $height = $size[1] * $a2;
  $x = ($orig[0] - $width) / 2;
  $y = 0;
}
$img = ImageCreateFromJpeg('IMG_0099.JPG');
$thumb = ImageCreateTrueColor($size[0], $size[1]);
ImageCopyResampled($thumb, $img, 0, 0, $x, $y, $size[0], $size[1], $width, $height);
header('Content-Type: ' . $orig['mime']);
switch ($orig[2]) {
  case IMG_JPG :
  case IMG_JPEG :
    ImageJPEG($thumb);
    break;
  case IMG_PNG :
    ImagePNG($thumb);
    break;
  case IMG_GIF :
    ImageGIF($thumb);
    break;
}
ImageDestroy($thumb);
ImageDestroy($img);
