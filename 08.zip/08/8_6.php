<?php
// 8_6.php

$orig = GetImageSize('IMG_0099.JPG');

$img = ImageCreateFromJpeg('IMG_0099.JPG');
$thumb = ImageRotate($img, 30, 0);
header('Content-Type: ' . $orig['mime']);
switch ($orig[2]) {
  case IMG_JPG :
  case IMG_JPEG :
    ImageJPEG($thumb);
    break;
  case IMG_PNG :
    ImagePNG($thumb);
    break;
  case IMG_GIF :
    ImageGIF($thumb);
    break;
}
ImageDestroy($thumb);
ImageDestroy($img);
