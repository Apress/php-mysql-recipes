<?php
// 8_7.php

$orig = GetImageSize('IMG_0099.JPG');

$img = ImageCreateFromJpeg('IMG_0099.JPG');
ImageFlip($img, IMG_FLIP_HORIZONTAL);
header('Content-Type: ' . $orig['mime']);
switch ($orig[2]) {
  case IMG_JPG :
  case IMG_JPEG :
    ImageJPEG($img);
    break;
  case IMG_PNG :
    ImagePNG($img);
    break;
  case IMG_GIF :
    ImageGIF($img);
    break;
}
ImageDestroy($img);
