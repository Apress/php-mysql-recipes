<?php
// 8_8.php

$orig = GetImageSize('IMG_0099.JPG');
$wm = GetImageSize('watermark.png');

$img = ImageCreateFromJpeg('IMG_0099.JPG');
$watermark = ImageCreateFromPng('watermark.png');

if ($orig[0] > $wm[0]) {
  $width = $wm[0];
  $height = $wm[1];
  $x = ($orig[0] - $wm[0]) / 2;
  $y = ($orig[1] - $wm[1]) / 2;
}
else {
  $d = $orig[0] / $wm[0];
  $width = $orig[0];
  $height = $wm[1] * $d;
  $x = 0;
  $y = ($orig[1] - $height) / 2;
}

ImageCopyResampled($img, $watermark, $x, $y, 0, 0, $width, $height, $wm[0], $wm[1]);
header('Content-Type: ' . $orig['mime']);
switch ($orig[2]) {
  case IMG_JPG :
  case IMG_JPEG :
    ImageJPEG($img);
    break;
  case IMG_PNG :
    ImagePNG($img);
    break;
  case IMG_GIF :
    ImageGIF($img);
    break;
}
ImageDestroy($watermark);
ImageDestroy($img);
