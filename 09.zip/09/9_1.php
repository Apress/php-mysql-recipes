<?php
// 9_1.php

function AddEmail($email) {
  // do the database query.
  echo "$email was added to the database\n";
}

if ($_POST['email']) {
  if (preg_match("/[a-z0-9]+@[a-z0-9]+\.[a-z0-9]+/i", $_POST['email'])) {
    AddEmail($_POST['email']);
  }
}
