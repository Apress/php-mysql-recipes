<?php
// 9_10.php
$html = <<<HEREDOC
<img src="/images/logo.png" />
<img alt="Photo" src="/images/photo.jpg" />
HEREDOC;
$body = preg_replace('/src="([^"]*)"/mi', 
                     'src="http://mydomain.com\1"', $html);
echo $body;
