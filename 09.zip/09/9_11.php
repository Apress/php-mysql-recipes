<?php
// 9_11.php
$html = <<<HEREDOC
<img src="/images/logo.png" />
<img src="background.png" />
<img alt="Photo" src="/images/photo.jpg" />
<img src="http://example.com/images/photo.jpg" />
HEREDOC;
if (preg_match_all('/src="([^"]*)"/mi', $html, $matches)) {
  foreach ($matches[0] as $i => $str) {
    if ($matches[1][$i][0] == "/") {
      $html = str_replace($str,
                          "src=\"http\"//mydomain.com{$matches[1][$i]}\"",
                          $html);
    }
    else if (substr($matches[1][$i], 0, 7) == "http://" ||
             substr($matches[1][$i], 0, 8) == "https://") {
      // Do nothing the URL is complete.
    }
    else {
      $dir = dirname($_SERVER['REQUEST_URI']);
      $html = str_replace($str,
                  "src=\"http\"//mydomain.com/{$dir }/{$matches[1][$i]}\"",
                  $html);
    }
  }
}
echo $html;
