<?php
// 9_2.php

function AddEmail($email) {
  // do the database query.
  echo "$email was added to the database\n";
}

if ($_POST['email']) {
  if (preg_match("/[a-z0-9]+@[a-z0-9]+\.[a-z0-9]+/i", 
                 $_POST['email'],
                 $matches)) {
    AddEmail($matches);
  }
}
