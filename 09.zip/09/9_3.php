<?php
// 9_3.php

$phone = str_replace([' ','.','-','(',')'], 
                     ['','','','',''], 
                     $_POST['phone']);
