<?php
// 9_4.php

$phone = preg_replace("/[^\d]/", "", $_POST['phone']);
