<?php
// 9_5.php

$phone = preg_replace("/[^\d]/", "", $_POST['phone']);
if (strlen($phone) == 10 || (strlen($phone) == 11 && $phone[0] == '1')) {
  echo "$phone is a valid US number\n";
}
