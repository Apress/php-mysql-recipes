<?php
// 9_6.php

$phone = preg_replace("/[^\d]/", "", $_POST['phone']);
if (preg_match("/^1?\d{10}$/", $phone)) {
  echo "$phone is a valid US number\n";
}
