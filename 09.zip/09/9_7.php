<?php
// 9_7.php

$txt = "I got a new car and I'm now looking for a new house";
if (preg_match("/new(( car| house)|)/", $txt, $matches) {
  print_r($matches);
}
