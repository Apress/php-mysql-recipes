<?php
// 9_8.php

$txt = "I got a new car and I'm now looking for a new house";
if (preg_match_all("/new(( car| house)|)/", $txt, $matches)) {
  print_r($matches);
}
