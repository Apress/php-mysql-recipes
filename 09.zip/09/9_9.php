<?php
// 9_9.php

$emails = <<<HEREDOC
Joe Smith <smithj@example.com>
"Scott, Colin" <scottc@example.com>
<new@example.com>
some other content
HEREDOC;

if (preg_match_all(
      '/^"?([a-z0-9, ]*)"? ?<([a-z0-9]+@[a-z0-9]+.[a-z0-9]+)>$/mi', 
      $emails, $matches)) {
  echo "names: " . implode(", ", $matches[1]) . "\n";
  echo "emails: " . implode(", ", $matches[2]) . "\n";
}
