<?php
// 10_1.php
$a = 5;
$a = "Some string";
$b = 5;
$b = (string)$b; 
