<?php
// 10_10.php
$a = 5;
$b = $a;
$a++;
echo "\$a = $a\n";
echo "\$b = $b\n";
