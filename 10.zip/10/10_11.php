<?php
// 10_11.php
$a = 5;
$b = &$a;
$a++;
echo "\$a = $a\n";
echo "\$b = $b\n";
