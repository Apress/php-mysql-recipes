<?php
// 10_13.php
$a = array(1,2,3,4,5,6,7,8,9);
foreach($a as $i => $e) {
  if ($e % 2 == 0) {
    $a[$i] = $e * 2;
  }
}
print_r($a);
