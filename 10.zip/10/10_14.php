<?php
// 10_14.php
$a = array(1,2,3,4,5,6,7,8,9);
foreach($a as &$e) {
  if ($e % 2 == 0) {
    $e *= 2;
  }
}
print_r($a);
