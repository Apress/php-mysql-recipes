<?php
// 10_15.php
define('MY_CONSTANT', 12);
function MyFunc($v) {
  return $v * MY_CONSTANT;
}
echo MyFunc(2);
