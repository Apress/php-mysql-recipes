<?php
// 10_16.php
$var = "abc";
$$var = 6;
echo $var . "\n";
echo $abc . "\n";
