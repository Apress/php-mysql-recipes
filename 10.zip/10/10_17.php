<?php
// 10_17.php
$var = "abc";
$$var = "def";
$$$var = "ghi";
$$$$var = 6;

echo $ghi;
