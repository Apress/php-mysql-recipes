<?php
// 10_18.php
$us = "m/d/Y";
$eu = "d-m-Y";
$format = "us";
echo date($$format);
