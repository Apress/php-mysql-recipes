<?php
// 10_19.php
$format = array(
  'us' => 'm/d/Y',
  'eu' => 'd-m-Y',
);
echo date($format['us']);
