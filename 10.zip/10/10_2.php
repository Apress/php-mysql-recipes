<?php
// 10_2.php
$a = 5;
$b = "10";
if ($b > $a) {
  echo '$b is greater than $a';
}
