<?php
// 10_20.php
$i = 100;
$f = 12.2;
$s = "abc";
$s2 = "100";

var_dump($i == $s2);
var_dump($i === $s2);
var_dump($i != $s2);
var_dump($i !== $s2);
var_dump($i >= $f);
var_dump($s <=> $s2);
var_dump($s2 <=> $s);
var_dump($s <=> $s);
