<?php
// 10_22.php
$a = 5;
$s = 'This string is '.
     'created by concatination of '.
     'strings and the variable $a '.
     "with the value $a\n";
