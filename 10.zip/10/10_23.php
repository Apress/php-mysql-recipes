<?php
// 10_23.php
$v = 8 - 7.7;
$u = 0.3;
echo "$v\n";
if ($v == $u) {
  echo "\$v == \$u\n";
}
else {
  echo "\$v != $u\n";
}
