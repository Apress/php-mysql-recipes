<?php
// 10_24.php
$epsilon = 0.00001;
$v = 8 - 7.7;
$u = 0.3;
echo "$v\n";
if (abs($v - $u) < $epsilon) {
  echo "\$v == \$u\n";
}
else {
  echo "\$v != $u\n";
}
