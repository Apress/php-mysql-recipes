<?php
// 10_25.php
$a = array();
