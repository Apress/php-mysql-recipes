<?php
// 10_26.php
$a = array(1, 2, "3", array(4, 5, 6));
