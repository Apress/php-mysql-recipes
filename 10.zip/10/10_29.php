<?php
// 10_29.php
$a = [
  'host' => 'localhost',
  'user' => 'root'
];
