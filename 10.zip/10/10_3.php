<?php
// 10_3.php
$a = array("abc", "def", "ghi");
$a = null;

$a = array("abc", "def", "ghi");
unset($a);
