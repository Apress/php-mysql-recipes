<?php
// 10_30.php
$a = [
  0 => '123',
  1 => null,
  'a' => 'abc',
  'b' => null
];

var_dump(isset($a[0]));
var_dump(isset($a[1]));
var_dump(isset($a['a']));
var_dump(isset($a['b']));

var_dump(array_key_exists(0, $a));
var_dump(array_key_exists(1, $a));
var_dump(array_key_exists('a', $a));
var_dump(array_key_exists('b', $a));
