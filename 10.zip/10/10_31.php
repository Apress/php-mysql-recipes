<?php
// 10_31.php
$a = [1, 2, 3];

list($v1) = $a;
echo "$v1\n";
list($v1, $v2) = $a;
echo "$v1, $v2\n";
list($v1, $v2, $v3) = $a;
echo "$v1, $v2, $v3\n";
list($v1, $v2, $v3, $v4) = $a;
echo "$v1, $v2, $v3, $v4\n";

$b = ['a' => 7, 'b' => 8];
list($x1, $x2) = $b;
echo "$x1, $x2\n";
