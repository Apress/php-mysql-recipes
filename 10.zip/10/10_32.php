<?php
// 10_32.php
$a = [
  'host' => 'localhost',
  'database' => 'mydb',
  'user' => 'user'
];
foreach($a as $key => $value) {
  if (isset($$key)) {
	$key = "prefix_" . $key;
  }
  $$key = $value;
}

echo "$host, $database, $user\n";
