<?php
// 10_33.php
$a = [
  'host' => 'localhost',
  'database' => 'mydb',
  'user' => 'user'
];
extract($a, EXTR_PREFIX_SAME, 'prefix');

echo "$host, $database, $user\n";
