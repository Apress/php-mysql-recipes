<?php
// 10_34.php
$a = [10, 15, 20, 25];
while ($b = each($a)) {
  echo $b . "\n";
}
