<?php
// 10_35.php
$a = [10, 15, 20, 25];
foreach($a as $b) {
  echo $b . "\n";
}
