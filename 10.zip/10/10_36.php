<?php
// 2_36.php
$a = 'value 1';
$b = 'value 2';
//This will output $a and $b
echo $a, $b, "\n";
// This will concatinate $a and $b and output the result
print $a . $b . "\n";
