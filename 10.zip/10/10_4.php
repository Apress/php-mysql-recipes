<?php
// 10_4.php
$a = 5;
$a = null;
var_dump(isset($a));
var_dump(empty($a));
var_dump(is_null($a));
unset($a);
var_dump(isset($a));
var_dump(empty($a));
var_dump(is_null($a));
