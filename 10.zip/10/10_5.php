<?php
// 10_5.php
$a = array();
for ($i = 0; $i < 100; $i++) {
  $a[] = "This is a short string";
  echo "Memory usage for $i elements = " . memory_get_usage() . "\n";
}
while (($i = sizeof($a))) {
  echo "Memory usage for $i elements = " . memory_get_usage() . "\n";
  unset($a[$i - 1]);
}
echo "Maximim memory usage = " . memory_get_peak_usage() . "\n";
