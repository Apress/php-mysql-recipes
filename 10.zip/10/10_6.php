<?php
// 10_6.php
$a = 5;
function MyTest() {
  $a = 7;
}
MyTest();
echo $a;
