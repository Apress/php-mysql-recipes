<?php
// 10_7.php
$a = 5;
function MyTest() {
  $a = 7;
  global $a;
  $a = 6;
}
MyTest();
echo $a;
