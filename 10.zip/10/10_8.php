<?php
// 10_8.php
$a = 5;
function MyTest() {
  $GLOBALS['a'] += 7;
}
MyTest();
echo $a;
