<?php
// 10_9.php
$i = PHP_INT_MAX;
echo $i . "\n";
echo gettype($i) . "\n";
$i++;
echo $i . "\n";
echo gettype($i) . "\n";
