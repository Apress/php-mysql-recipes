<?php
// 11_1.php

function DeleteRows() {
  $con = mysqli_connect('host', 'user', 'secret');
  if ($con) {
    mysqli_select_db($con, 'mydb');
    mysqli_query($con, "delete from mytable;");
    mysqli_close($con);
  }
  else {
    echo "No database connection";
  }
}

// Call the function
DeleteRows();
