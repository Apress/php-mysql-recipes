<?php
// 11_10.php

$con = mysqli_connect('host', 'user', 'secret');
if ($con) {
  mysqli_select_db($con, 'mydb');
}

function SelectRows(string $table, &$data) {
  global $con;
  $data = [];
  if ($con) {
    $where = "";
    $rs = mysqli_query($con, "select * from {$table};");
    if ($rs) {
      while($row = mysqli_fetch_assoc($rs)) {
        $data[] = $row;
      }
      mysqli_free_result($rs);
    }
  }
  else {
    echo "No database connection";
  }
  return sizeof($data);
}

// Call the function
if (SelectRows("mytable", $mytable) {
  // Do Something
}

mysqli_close($con);
