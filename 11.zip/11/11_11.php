<?php
// 11_11.php

if (!function_exists('MyFunction')) {
  include "myfunc.inc";
}
