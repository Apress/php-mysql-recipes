<?php
// 11_12.php

$v = 1.25;

function FormatInteger($i) {
}
function FormatFloat($f) {
}
function FormatBool($b) {
}
function FormatString($s) {
}

switch (gettype($v)) {
  case 'integer' :
    FormatInteger($v);
    break;
  case 'double' :
    FormatFloat($v);
    break;
  case 'boolean' :
    FormatBool($v);
    break;
  case 'string' :
    FormatString($v);
    break;
}
