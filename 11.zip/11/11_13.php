<?php
// 11_13.php

$v = 1.25;

function FormatInteger($i) {
}
function FormatDouble($f) {
}
function FormatBoolean($b) {
}
function FormatString($s) {
}

$f = "Format" . gettype($v);
if (is_callable($f)) {
  $f($v);
}
