<?php
// 11_14.php

function compare($a, $b) {
  if ($a == $b) {
    return 0;
  }
  return ($a < $b) ? -1 : 1;
}
$arr = [1, 9, 3, 1, 5, 7, 4];
usort($arr, 'compare');
print_r($arr);
