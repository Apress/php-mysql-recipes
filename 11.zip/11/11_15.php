<?php
// 11_15.php

$arr = [1, 9, 3, 1, 5, 7, 4];
usort($arr, function($a, $b) { return $a <=> $b; });
print_r($arr);
