<?php
// 11_16.php

if (date('w') == 3) {
  $profit = function($p) {
    return $p * 1.25;
  };
}
else {
  $profit = function($p) {
    return $p * 1.30;
  };
}
// read all transactions from the database
foreach($transaction as $t) {
  $p = $profit($t);
}
