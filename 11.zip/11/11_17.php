<?php
// 11_17.php

$profit = function($p) {
  return $p * 1.30;
};

echo $p = $profit(100) . "\n";

// Do some stuff

$profit = function($p) {
  return $p * 1.25;
};

echo $p = $profit(100) . "\n";
