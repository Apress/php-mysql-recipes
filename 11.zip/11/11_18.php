<?php
// 11_18.php
function A() {
  function B($i) {
    echo "B called with $i\n";
  }
  for ($i = 1; $i < 3; $i++) {
    B($i);
  }
  echo "A called\n";
}
A();
B(0);
