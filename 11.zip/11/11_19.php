<?php
// 11_19.php
function A() {
  $f = function ($i) {
    echo "B called with $i\n";
  };
  for ($i = 1; $i < 3; $i++) {
    $f($i);
  }
  echo "A called\n";
}
A();
A();
