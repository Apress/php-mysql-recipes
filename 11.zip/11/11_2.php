<?php
// 11_2.php

$con = mysqli_connect('host', 'user', 'secret');
if ($con) {
  mysqli_select_db($con, 'mydb');
}

function DeleteRows() {
  if ($_GLOBALS['con']) {
    mysqli_query($_GLOBALS['con'], "delete from mytable;");
  }
  else {
    echo "No database connection";
  }
}

// Call the function
DeleteRows();

mysqli_close($con);
