<?php
// 11_20.php

function MyFunc() {
  echo func_num_args() . "\n";
}

MyFunc("A", 1, [1,2,3]);
