<?php
// 11_21.php

function MyFunc(string $s, int $i = 0) {
  echo func_num_args() . "\n";
  print_r(func_get_args());
}

MyFunc("Abc", 1, [1,2,3]);
