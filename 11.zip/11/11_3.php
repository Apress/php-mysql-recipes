<?php
// 11_3.php

$con = mysqli_connect('host', 'user', 'secret');
if ($con) {
  mysqli_select_db($con, 'mydb');
}

function DeleteRows() {
  global $con;
  if ($con) {
    mysqli_query($con, "delete from mytable;");
  }
  else {
    echo "No database connection";
  }
}

// Call the function
DeleteRows();

mysqli_close($con);
