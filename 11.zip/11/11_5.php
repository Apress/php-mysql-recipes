<?php
// 11_5.php

$con = mysqli_connect('host', 'user', 'secret');
if ($con) {
  mysqli_select_db($con, 'mydb');
}

function DeleteRows($options) {
  global $con;
  if ($con) {
    if (is_array($options) && $options['table']) {
      $where = "";
      if (is_array($options['ids']) && sizeof($options['ids'])) {
        $strids = implode(", ", $options['ids']);
        $where = " where id in ({$strids})";
      }
      mysqli_query($con, "delete from {$options['table']}{$where};");
    }
    else {
      echo '$options must be an array';
    }
  }
  else {
    echo "No database connection";
  }
}

// Call the function
$params = [
  'ids' => [1, 3, 5],
  'table' => 'mytable'
];
DeleteRows($params);

mysqli_close($con);
