<?php
// 11_9.php

$con = mysqli_connect('host', 'user', 'secret');
if ($con) {
  mysqli_select_db($con, 'mydb');
}

function DeleteRows(string $table, array $ids = []) {
  global $con;
  if ($con) {
    $where = "";
    if (is_array($ids) && sizeof($ids)) {
      $strids = implode(", ", $ids);
      $where = " where id in ({$strids})";
    }
    mysqli_query($con, "delete from {$table}{$where};");
    return mysqli_affected_rows($con);
  }
  else {
    echo "No database connection";
    return -1;
  }
}

// Call the function
DeleteRows("mytable");

mysqli_close($con);
