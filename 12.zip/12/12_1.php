<?php
// 12_1.php
header("Content-Type: text/plain");
?>
This software is licensed under the MIT license
Plese see https://opensource.org/licenses/MIT for details
