<?php
// 12_10.php

$options = array('http' => array(
  'user_agent' => 'Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25',
));

$context = stream_context_create($options);
$data = file_get_contents(
  'http://mydomain.com/myfile.php',
  false,
  $context
);
