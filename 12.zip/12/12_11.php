<?php
// 12_11.php

function FormEncode($data) {
  $val = [];
  foreach($data as $key => $value) {
    $val[] = "$key=$value";
  }
  return implode("&", $val);
}

$content = [
  'a' => 1,
  'b' => 2,
];

$options = array('http' => array(
  'method' => 'POST',
  'content' = FormEncode($content)
));

$context = stream_context_create($options);
$data = file_get_contents(
  'http://mydomain.com/myfile.php',
  false,
  $context
);

var_dump($data);
var_dump($http_response_header);
