<?php
// 12_12.php
if ($_SERVER['REQUEST_SCHEME'] == 'http') {
  header("Location: https://{$_SERVER['SERVER_NAME']}" .
    $_SERVER['REQUEST_URI']);
  exit;
}
