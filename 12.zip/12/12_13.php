<?php
// 12_13.php
$resp = [
  'a' => 1,
  'b' => 2
];
header('Content-Type: application/json');
echo json_encode($resp);
