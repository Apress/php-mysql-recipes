#!/usr/bin/env php 
<?php
// 12_14.php

require('./websockets.php'); 

class echoServer extends WebSocketServer {
  protected function process ($user, $message) {
    $this->send($user, str_reverse($message));   
  }
  protected function connected ($user) {
  }

  protected function closed ($user) {
  }
}

$echo = new echoServer("0.0.0.0","9000");

try {
  $echo->run();
}
catch (Exception $e) {
  $echo->stdout($e->getMessage());
}
