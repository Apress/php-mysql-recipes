<?php
// 12_2.php
$mobile = '/(ios|ipod|mobile|pad|phone|tablet|' .
          'symbian|android|blackberry|webos)/i';
if (is_set($_SERVER['HTTP_USER_AGENT']) &&
    preg_match($mobile_agents, $_SERVER['HTTP_USER_AGENT'])) {
    header("Location: http://m.mysite.com");
}
