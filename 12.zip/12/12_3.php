<?php
//12_3.php

if ($_COOKIE['visited']) {
  echo "Welcome Back!";
}
else {
  echo "Welcome to mydomain.com";
}
SetCookie('visited', time(), time() + 30 * 86400);
