<?php
//12_4.php

if (empty($_COOKIE['access']) || $_COOKIE['access'] < time() - 15 * 60) {
  SetCookie('access');
  Login();
}
else {
  SetCookie('access', time(), 0);
  // Perform action;
}
