<?php
// 12_5.php

if ($_SERVER['REQUEST_SCHEME'] == 'http') {
  $Location = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
  header("Location: Error! Hyperlink reference not valid.}");
  exit;
}
