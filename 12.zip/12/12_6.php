<?php
// 12_6.php

if (empty($_POST)) {
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
<script src="/js/jstz.js"></script>
</head>
<body>
<form method="POST" action="{$_SERVER['PHP_SELF']}">
  <div>
    <label for="user">User Name</label>
    <input name="user" type="text" required />
   </div>
  <div>
    <label for="timezone">Time Zone</label>
    <input id="tz" name="timezone" type="text" required />
   </div>
  <div>
    <input type="submit" />
  </div>
</form>
<script>
var timezone = jstz.determine();
var tz = document.getElementById('tz');
tz.value = timezone.name();
</script>
</body>
</html>
HEREDOC;
}
else {
  date_default_timezone_set($_POST['timezone']);
  $lt = date('M d Y H:i:s');
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
<script src="/js/jstz.js"></script>
</head>
<body>
<div>Welcome: {$_POST['user']}</div>
<div>Local time is: {$lt}</div>
</body>
</html>
HEREDOC;
}
