<?php
// 12_7.php

date_default_timezone_set('UTC');
session_start();
if ($_SESSION['last_request']) {
  echo "Las access was " . date('M d Y H:i:s');
}
else {
  echo 'This is the first request to the site';
}
$_SESSION['last_request'] = time();
