<?php
// 12_8.php

$size = [160, 120];
$img_name = 'IMG_0099.JPG';
$orig = GetImageSize($img_name);

$a1 = $size[0] / $size[1];
$a2 = $orig[0] / $orig[1];

if ($a1 > $a2) {
  $d = ceil($orig[0] / $size[0]);
}
else {
  $d = ceil($orig[1] / $size[1]);
}
$w = $orig[0] / $d;
$h = $orig[1] / $d;
header('Content-Type: ' . $orig['mime']);
if ($_REQUEST['Download']) {
  header('Content-Disposition: attachment; filename="' . $img_name . '"');
  readfile($img_name);
}
else {
  $img = ImageCreateFromJpeg('IMG_0099.JPG');
  $thumb = ImageScale($img, $w, $h);
  switch ($orig[2]) {
    case IMG_JPG :
    case IMG_JPEG :
      ImageJPEG($thumb);
      break;
    case IMG_PNG :
      ImagePNG($thumb);
      break;
    case IMG_GIF :
      ImageGIF($thumb);
      break;
  }
  ImageDestroy($thumb);
  ImageDestroy($img);
}
