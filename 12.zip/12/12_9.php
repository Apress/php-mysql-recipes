<?php
// 12_9.php

function Cache($last_mod, $ttl = 86400) {
  $gmt_mod = gmdate('D, d M Y H:i:s', $last_mod) . ' GMT';
  $gmt_expires = gmdate('D, d M Y H:i:s', time() + $ttl) . ' GMT';

  header("Pragma: Cache");
  header("Cache-Control: max-age=0, must-revalidate");
  header("Last-Modified: " . $gmt_mod);
  header("Expires: " . $gmt_expired);

  if (!empty($_SERVER['HTTP_IF_MODIFIED_SINCE']) &&
      $_SERVER['HTTP_IF_MODIFIED_SINCE'] == $gmt_mod) {
    http_response_code(304);
    exit();
  }
}

// Lookup the timestamp when the data was changed
$LastMod = GetModified();
Cache($LastMod);

// Check for a cached version on the server
if (file_exists("cache_12_9.php")) {
  readfile("cache_12_9.php");
}
else {
  // Generate the content
}
