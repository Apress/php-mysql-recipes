<?php
// 13_1.php

if (empty($_POST)) {
  // nothing posted show the form
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
  <title>Contact Us</title>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <!-- Optional theme --> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
</head>
<body>
<form name="contact" method="POST" action="{$_SERVER['PHP_SELF']}">
  <div>
    <label for="name">Name</label>
    <input class="form-control" name="name" type="text" />
  </div>
  <div> 
    <label for="email">Email</label>
    <input class="form-control" name="email" type="text" />
  </div>
  <div>
    <label for="phone">Phone</label>
    <input class="form-control" name="phone" type="text" />
  </div>
  <div> 
    <label>Best way to contact you</label>
    <div class="radio">
      <label><input name="cnt" type="radio" value="0"/>Don't contact</label>
    </div>
    <div class="radio">
      <label><input name="cnt" type="radio" value="1"/>Email</label>
    </div>
    <div class="radio">
      <label><input name="cnt" type="radio" value="2"/>Phone</label>
    </div>
  </div>
  <button class="btn btn-default" onclick="document.contact.submit()">Submit</button>
</form>
</body>
</html>
HEREDOC;
}
else {
  switch ($_POST['cnt']) {
    case 0:
    default:
      $contact = "We will not contact you!";
      break;
    case 1:
      $contact = "We will contact you via email!";
      break;
    case 2:
      $contact = "We will contact you via phone!";
      break;
  }
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
  <title>Thank You</title>
</head>
</body>
<div>Thank you for your input. We have received the following input from you:<div>
<div>Name: {$_POST['name']}</div>
<div>Email: {$_POST['email']}</div>
<div>Phone: {$_POST['phone']}</div>
<div>{$contact}</div>
</body>
</html>
HEREDOC;
  $mysqli = new mysqli("localhost", "user", "secret", "contact_db");
  $name = $mysqli->real_escape_string($_POST['name']);
  $email = $mysqli->real_escape_string($_POST['email']);
  $phone = $mysqli->real_escape_string($_POST['phone']);
  $cnt = (int)$_POST['cnt'];
  $SQL = "insert into contacts (contact_name, email, phone, cnt) values " .
         "('{$name}', '{$email}', '{$phone}', $cnt)";
  $mysqli->query($SQL);
}
