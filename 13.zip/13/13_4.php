<?php
// 13_4.php

class HTMLForm {
  private $id;
  private $action;
  private $method;
  private $inputs = [];

  function __constructor($id, $action, $method = "POST") {
    $this->id = $id;
    $this->action = $action;
    $this->method = $method;
  }

  function AddInput($type, $name, $label, $value = null) {
    $this->inputs[] = [
      $type,
      $name,
      $label,
      $value
    ];
  }

  function __toString() {
    $form = '<form id="%s" action="%s", method="%s>%s</form>';
    $inputs = [];
    foreach($this->inputs as $input) {
      switch($input[0]) {
        case "hidden" :
          $template = '<input type="hidden" name="%s" value="%s" />';
          $inputs[] = sprintf($template, $input[1], $input[3]);
          break;
        case "text" :
          $template = '<div><label for="%s">%s</label><input type="text" name="%s" value="%s" /></div>';
          $inputs[] = sprintf($template, $input[1], $input[2], $input[1], $input[3]);
          break;
        case "textarea" :
          $template = '<div><label for="%s">%s</label><textarea type="text" name="%s" />%s</textarea></div>';
          $inputs[] = sprintf($template, $input[1], $input[2], $input[1], $input[3]);
          break;
        case "number" :
          $template = '<div><label for="%s">%s</label><input type="number" name="%s" value="%s" /></div>';
          $inputs[] = sprintf($template, $input[1], $input[2], $input[1], $input[3]);
          break;
        case "select" :
          $template = '<div><label for="%s">%s</label><select name="%s" >%s</select></div>';
          $options = [];
          if (is_array($value)) {
            $option = '<option value="%s">%s</option>';
            foreach($value as $k => $v) {
              $options[] = sprintf($option, $k, $v);
            }
          }
          $inputs[] = sprintf($template, $input[1], $input[2], $input[1], implode("", $options));
          break;
      }
    }
    $form = sprintf($form, $this->id, $this->action, $this->method, implode("", $inputs));
    return $form;
  }
}
