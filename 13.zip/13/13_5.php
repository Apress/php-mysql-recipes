<?php
// 13_5.php
require "./13_4.php";

$form = new HTMLForm('contact', $_SERVER['PHP_SELF']);
$form->AddInput('text', 'name', 'Name');
$form->AddInput('text', 'email', 'Email');
$form->AddInput('text', 'phone', 'Phone');
$form->AddInput('textarea', 'comment', 'Comment');

echo <<<HEREDOC
<!DOCTYPE html>
<html>
<body>
$form
</body>
</html>
HEREDOC;
