<?php
// 13_6.php

class HTMLForm {
  private $id;
  private $action;
  private $method;
  private $inputs = [];

  function __constructor($id, $action, $method = "POST") {
    $this->id = $id;
    $this->action = $action;
    $this->method = $method;
  }

  function AddHidden($name, $value = null) {
    $this->inputs[] = <<<HEREDOC
  <input type="hidden" name="{$name}" value="{$value}" />
HEREDOC;
  }

  function AddText($name, $label, $value = null, $required = false) {
	$attrib = $required ? " required" : "";
    $this->inputs[] = <<<HEREDOC
<div>
  <label for="{$name}">{$label}</label>
  <input type="text" name="{$name}" value="{$value}"{$attrib} />
</div>
HEREDOC;
  }

  function AddTextArea($name, $label, $value = null) {
    $this->inputs[] = <<<HEREDOC
<div>
  <label for="{$name}">{$label}</label>
  <textarea name="{$name}">{$value}</textarea>
</div>
HEREDOC;
  }

  function AddNumber($name, $label, $value = null, $required = false, $min = null, $max = null) {
	$attrib = $required ? " required" : "";
	if (is_numeric($min)) {
	  $attrib .= " min=\"{$min}\"";
	}
	if (is_numeric($max)) {
	  $attrib .= " max=\"{$max}\"";
	}
    $this->inputs[] = <<<HEREDOC
<div>
  <label for="{$name}">{$label}</label>
  <input type="number" name="{$name}" value="{$value}"{$attrib} />
</div>
HEREDOC;
  }

  function AddSelect($name, $label, $values = [], $selected = null) {
	$options = [];
	if (is_array($values)) {
	  $option = '<option value="%s"%s>%s</option>';
	  foreach($values as $k => $v) {
		if ($k == $selected) {
          $options[] = sprintf($option, $k, " selected", $v);
		}
		else {
          $options[] = sprintf($option, $k, "", $v);
		}
	  }
	}
	$options = implode("", $options);
    $this->inputs[] = <<<HEREDOC
<div>
  <label for="{$name}">{$label}</label>
  <select name="{$name}">$options</select>
</div>
HEREDOC;
  }

  function __toString() {
    $form = '<form id="%s" action="%s", method="%s>%s</form>';
    $inputs = [];
    $form = sprintf($form, $this->id, $this->action, $this->method, implode("", $this->inputs));
    return $form;
  }
}
