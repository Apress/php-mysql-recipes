<?php
// 13_7.php
require "./13_6.inc";

$form = new HTMLForm('contact', $_SERVER['PHP_SELF']);
$form->AddHidden('form', 'Contact');
$form->AddText('name', 'Name', null, true);
$form->AddText('email', 'Email', null, true);
$form->AddText('phone', 'Phone');
$form->AddSelect('ref', 'How did your find us?', ['Google', 'Bing', 'Ask', 'Yahoo', 'Other']);
$form->AddTextarea('comment', 'Comment');

echo <<<HEREDOC
<!DOCTYPE html>
<html>
<body>
$form
</body>
</html>
HEREDOC;
