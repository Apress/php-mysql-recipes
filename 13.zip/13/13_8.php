<?php
// 13_8.php

if (empty($_POST)) {
  // nothing posted show the form
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
  <title>File Upload</title>
</head>
<body>
<form name="contact" method="POST" action="{$_SERVER['PHP_SELF']}" enctype="multipart/form-data" >
  <div>
    <label for="name">Name</label>
    <input name="name" type="text" />
  </div>
  <div> 
    <label for="email">File</label>
    <input name="file" type="file" />
  </div>
  <button class="btn btn-default" onclick="document.contact.submit()">Submit</button>
</form>
</body>
</html>
HEREDOC;
}
else {
  print("<pre>");
  print_r($_POST);
  print_r($_FILES);
  print("</pre>");
}
