<?php
// 14_1.php
// Process request and make a response
header("Content-Type: text/xml");
if ($error) {
  $resp = <<<HEREDOC
<?xml version="1.0" encoding="UTF-8"?>
<error>
  <code>100</code>
  <message>The insert failed</message>
</error>
HEREDOC;
}
else {
  $resp = <<<HEREDOC
<?xml version="1.0" encoding="UTF-8"?>
<success>
  <message>The record was added</message>
</sucess>
HEREDOC;
}
