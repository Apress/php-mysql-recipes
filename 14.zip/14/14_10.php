<?php
// 14_10.php

$wddx = <<<HEREDOC
<wddxPacket version='1.0'>
<header><comment>Packet</comment></header>
<data><string>PHP &amp; MySQL Recipes</string></data>
</wddxPacket>
HEREDOC;

var_dump(wddx_deserialize($wddx));
