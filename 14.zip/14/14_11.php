<?php
// 14_11.php

$int = 1234;
$str = "PHP & MySQL Recipes";
$arr = [
  12,
  "abc",
  [
    3.15,
    7.25
  ]
];
$packet_id = wddx_packet_start("Packet");
wddx_add_vars($packet_id, "int");
wddx_add_vars($packet_id, "str");
wddx_add_vars($packet_id, "arr");

echo wddx_packet_end($packet_id);
