<?php
// 14_12.php

class Math {
  function Add($i, $j) {
    return $i + $j;
  }

  function Subtract($i, $j) {
    return $i - $j;
  }

  function Multiply($i, $j) {
    return $i * $j;
  }
}
