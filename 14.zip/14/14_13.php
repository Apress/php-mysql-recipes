<?php
// 14_13.php
include "./14_12.php";
$server = new SoapServer(null, ['uri' => 'http://localhost/14_13.php']);
$server->setClass('Math');
$server->handle();
