<?php
// 14_14.php
$client = new SoapClient(null, array(
  'location' => "http://localhost/14_13.php",
  'uri'      => "http://localhost/14_13.php",
  'trace'    => 1
));

echo $return = $client->__soapCall("Add",array(5, 2)) . "\n";
echo $return = $client->__soapCall("Subtract",array(5, 2)) . "\n";
echo $return = $client->__soapCall("Multiply",array(5, 2)) . "\n";
