<?php
// 14_15.php
include "./14_12.php";
$server = new SOAPServer('math.wsdl', ['encoding'=>'UTF-8']);
$server->setClass('Math');
$server->handle();
