<?php
// 14_16.php
$client = new SoapClient('https://localhost/math.wsdl');

echo $return = $client->Add(5, 2) . "\n";
echo $return = $client->Subtract(5, 2) . "\n";
echo $return = $client->Multiply(5, 2) . "\n";
