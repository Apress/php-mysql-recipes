<?php
// 14_2.php
$xml = simplexml_load_file("http://api.openweathermap.org/data/2.5/weather?q=Los%20Angeles,us&mode=xml&appid=<API KEY>");
print_r($xml);
