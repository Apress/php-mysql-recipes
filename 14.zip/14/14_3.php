<?php
// 14_3.php

$xml = simplexml_load_file('http://api.openweathermap.org/data/2.5/weather?q=Los%20Angeles,us&mode=xml&appid=<API KEY>');
foreach($xml as $attrib => $value) {
  echo $attrib . "\n";
}
