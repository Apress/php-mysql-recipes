<?php
// 14_4.php

$xml = simplexml_load_file('http://api.openweathermap.org/data/2.5/weather?q=Los%20Angeles,us&mode=xml&appid=<API KEY>');

echo "City: {$xml->city['name']}\n";

if ($xml->temperature['unit'] == 'kelvin') {
    $k = $xml->temperature['value'];
    $c = $k - 273.15;
    $f = $c * 9 / 5 + 32;
}
printf("Temperature: %3.1f K / %3.1f C / %3.1f F\n", $k, $c, $f);
