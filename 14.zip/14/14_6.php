<?php
// 14_6.php
$planets = [
  'mercury' => [
    'type' => 'rock',
    'dist' => 0.39,
    'moons' => 0,
    'temp' => 452
  ],
  'venus' => [
    'type' => 'rock',
    'dist' => 0.723,
    'moons' => 0,
    'temp' => 726
  ],
  'earth' => [
    'type' => 'rock',
    'dist' => 1,
    'moons' => 1,
    'temp' => 285
  ],
  'mars' => [
    'type' => 'rock',
    'dist' => 1.524,
    'moons' => 2,
    'temp' => 240
  ],
  'jupiter' => [
    'type' => 'gas',
    'dist' => 5.203,
    'moons' => 67,
    'temp' => 120
  ],
  'saturn' => [
    'type' => 'gas',
    'dist' => 9.539,
    'moons' => 62,
    'temp' => 88
  ],
  'uranus' => [
    'type' => 'gas',
    'dist' => 19.18,
    'moons' => 27,
    'temp' => 59
  ],
  'neptune' => [
    'type' => 'gas',
    'dist' => 30.06,
    'moons' => 13,
    'temp' => 48
  ],
  'plutu' => [
    'type' => 'rock',
    'dist' => 39,53,
    'moons' => 4,
    'temp' => 37
  ],
];

$base = "<?xml version=\"1.0\" ?><planets></planets>";
$xml = new SimpleXMLElement($base);

foreach($planets as $name => $data) {
  $p = $xml->addChild('planet');
  $p->addAttribute('name', $name);
  $a = $p->addChild('dist');
  $a->addAttribute('value', $data['dist']);
  $a->addAttribute('unit', 'AU');
  $p->addChild('moons', $data['moons']);
  $a = $p->addChild('temp');
  $a->addAttribute('value', $data['temp']);
  $a->addAttribute('unit', 'kelvin');
}
header("Content-Type: text/xml");
echo $xml->asXML();
