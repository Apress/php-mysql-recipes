<?php
//14_7.php

class RSSWriter extends domDocument {
  private $rss;
  private $channel;
  
  function __construct($xml = "1.0", $encoding = "UTF-8") {
    parent::__construct($xml, $encoding);
    $this->formatOutput = true;
    $this->rss = $this->CreateElement("rss");
    $this->rss->setAttribute("version", "2.0");
    $this->channel = $this->CreateElement("channel");
  }

  function SetChannel($title, $description, $link, $pubdate, $ttl=1800) {
    $element = $this->CreateElement('title');
    $element->appendChild($this->CreateTextNode($title));
    $this->channel->appendChild($element);

    $element = $this->CreateElement('description');
    $element->appendChild($this->CreateTextNode($description));
    $this->channel->appendChild($element);

    $element = $this->CreateElement('link');
    $element->appendChild($this->CreateTextNode($link));
    $this->channel->appendChild($element);    

    $element = $this->CreateElement('pubDate');
    $element->appendChild($this->CreateTextNode(gmdate("D, d M Y H:i:s", (int)$pubdate) . " GMT"));
    $this->channel->appendChild($element);    

    $element = $this->CreateElement('ttl');
    $element->appendChild($this->CreateTextNode($ttl));
    $this->channel->appendChild($element);    
  }
  
  function AddItem($title, $link, $description = null, $attribs = null) {
    $item = $this->CreateElement("item");

    if (!empty($title)) {
      $obj = $this->CreateElement("title");
      $obj->appendChild($this->CreateTextNode($title));
      $item->appendChild($obj);
    }

    if (!empty($link)) {
      $obj = $this->CreateElement("link");
      $obj->appendChild($this->CreateTextNode($link));
      $item->appendChild($obj);
    }

    if (!empty($attribs["description"])) {
      $obj = $this->CreateElement("description");
      $obj->appendChild($this->CreateTextNode($attribs["description"]));
      $item->appendChild($obj);
    }

    if (!empty($attribs["pubDate"])) {
      $obj = $this->CreateElement("pubDate");
      $obj->appendChild($this->CreateTextNode(gmdate("D, d M Y H:i:s", (int)$attribs["pubDate"]) . " GMT"));
      $item->appendChild($obj);
    }

    if (!empty($attribs["category"])) {
      $obj = $this->CreateElement("category");
      $obj->appendChild($this->CreateTextNode($attribs["category"]));
      $item->appendChild($obj);
    }

    if (!empty($attribs["author"])) {
      $obj = $this->CreateElement("author");
      $obj->appendChild($this->CreateTextNode($attribs["author"]));
      $item->appendChild($obj);
    }

    if (!empty($attribs["guid"])) {
      $obj = $this->CreateElement("guid");
      $obj->appendChild($this->CreateTextNode($attribs["guid"]));
      $item->appendChild($obj);
    }

    if (!empty($attribs["comments"])) {
      $obj = $this->CreateElement("comments");
      $obj->appendChild($this->CreateTextNode($attribs["comments"]));
      $item->appendChild($obj);
    }

    $this->channel->appendChild($item);
  }

  function Output($file_name = "opensearch.xml") {
    $this->rss->appendChild($this->channel);
    $this->appendChild($this->rss);
    
    header("Content-Type: text/xml; name=\"{$file_name}\"");
    header("Content-Disposition: inline; filename=\"{$file_name}\"");
    echo $this->saveXML();    
  }
}

$rss = new RSSWriter();
$rss->SetChannel("PHP & MySQL Recipes", "A book about PHP and MySQL", "http://example.com", time());
$rss->AddItem("PHP 7", "http://php.net", "The new and faster version of php");
$rss->AddItem("MariaDB", "http://mariadb.org", "The open source database");
$rss->Output();
