<?php
// 14_8.php

date_default_timezone_set('America/Los_Angeles');

$feeds = [
  'https://www.nasa.gov/rss/dyn/breaking_news.rss',
  'http://www.nasaspaceflight.com/feed/'
];

class RSSReader {
  private $xml;
  
  function __construct($url) {
    $this->xml = simplexml_load_file($url);
  }
  
  function channel($name) {
	return $this->xml->channel->$name;
  }
  
  function items() {
	$i = [];
	foreach($this->xml->channel->item as $item) {
	  $i[] = [
	    (string)$item->title,
	    (string)$item->description,
	    (string)$item->link,
	    strtotime((string)$item->pubDate)
	  ];
	}
	return $i;
  }
}

foreach($feeds as $f) {
  $rss = new RSSReader($f);
  echo "<div>Channel: {$rss->channel('title')}</div>";
  echo "<div>{$rss->channel('description')}</div>";
  foreach($rss->items() as $item) {
	echo <<<HEREDOC
<div>
  <a href="{$item[2]}">{$item[0]}</a>
  <div>{$item[1]}</div>
</div>
HEREDOC;
  }
}
