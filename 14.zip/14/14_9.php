<?php
// 14_9.php

echo wddx_serialize_value("PHP & MySQL Recipes", "Packet");
