<?php
// 15_1.php
$languages = [
  'PHP', 'JavaScript',
  'C', 'C++', 'C#', 'Objective-C',
  'Python', 'Java', 'Ruby',
  'Visual Basic',
  'Scala'
];
shuffle($languages);
$data = array_slice($languages, 0, 3);

$html = "";
foreach($data as $lang) {
  $html .= "<li>$lang</li>";
}
if ($_REQUEST['data']) {
  echo $html;
}
else {
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
<script src="https://code.jquery.com/jquery-1.12.2.min.js"
        integrity="sha256-lZFHibXzMHo3GGeehn1hudTAP3Sc0uKXBXAzHX1sjtk="
        crossorigin="anonymous"></script>
</bead>
<body>
  <h1>Programming Languages</h1>
  <ul id="lang">
    $html
  </ul>
  <button onclick="Update()">Update</button>
<script>
function Update() {
  $.get("{$_SERVER['PHP_SELF']}?data=1", function(data) {
    $("#lang").html(data);
  });
}
</script>
</body>
</html>
HEREDOC;
}
