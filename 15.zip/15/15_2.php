<?php
// 15_2.php
$languages = [
  'PHP', 'JavaScript',
  'C', 'C++', 'C#', 'Objective-C',
  'Python', 'Java', 'Ruby',
  'Visual Basic',
  'Scala'
];
shuffle($languages);
$data = array_slice($languages, 0, 3);

if ($_REQUEST['data']) {
  header("Content-Type: application/json");
  echo json_encode($data);
}
else {
  $html = "";
  foreach($data as $lang) {
    $html .= "<li>$lang</li>";
  }
  echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
<script src="https://code.jquery.com/jquery-1.12.2.min.js"
        integrity="sha256-lZFHibXzMHo3GGeehn1hudTAP3Sc0uKXBXAzHX1sjtk="
        crossorigin="anonymous"></script>
</bead>
<body>
  <h1>Programming Languages</h1>
  <ul id="lang">
    $html
  </ul>
  <button onclick="Update()">Update</button>
<script>
function Update() {
  $.getJSON("{$_SERVER['PHP_SELF']}?data=1", function(data) {
    var html = '';
    $.each(data, function(key, value) {
      if (value == 'PHP') {
        html += '<li><b>PHP</b></li>';
      }
      else {
        html += '<li>' + value + '</li>';
      }
    });
    $('#lang').html(html);
  });
}
</script>
</body>
</html>
HEREDOC;
}
