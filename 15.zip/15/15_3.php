<?php
// 15_3.php
$url = "http://localhost/15_2.php?data=1";
$response = file_get_contents($url);
$languages = json_decode($response);
var_dump($languages);
