<?php
// 15_4.php

$json = file_get_contents('http://api.openweathermap.org/data/2.5/weather?q=Los%20Angeles,usxxx&appid=<API KEY>');
$weather = json_decode($json);

echo "City: {$weather->name}\n";

$k = $weather->main->temp;
$c = $k - 273.15;
$f = $c * 9 / 5 + 32;

printf("Temperature: %3.1f K / %3.1f C / %3.1f F\n", $k, $c, $f);

echo "Wind: {$weather->wind->speed} mph, direction: {$weather->wind->deg}\n";
