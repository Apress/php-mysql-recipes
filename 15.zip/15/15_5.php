<?php
// 15_5.php

class JsonResource {
  function __construct($type, $id) {
    $this->type = $type;
    $this->id = $id;
    $this->addLink('self', "$type/$id");
  }
  
  function addAttribute($name, $value) {
    if (!$this->attributes) {
      $this->attributes = new stdClass();
    }
    $this->attributes->$name = $value;
  }
  
  function addLink($name, $value) {
    if (!$this->links) {
      $this->links = new stdClass();
    }
    $this->links->$name = "http://localhost/$value";
  }
}

class JsonApi {  
  function addResource($data) {
    $this->data = $data;
  }
  
  function addLink($name, $value) {
    if (!$this->links) {
      $this->links = new stdClass();
    }
    $this->links->$name = "http://localhost/$value";
  }

  function __toString() {
    return json_encode($this, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  }
}

$user = new JsonResource('user', 123);
$user->addAttribute('name', 'John Smith');
$user->addAttribute('age', 25);

$api = new JsonApi();
$api->addResource($user);

header("Content-Type: application/vnd.api+json");
echo $api;
