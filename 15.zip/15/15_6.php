<?php
// 15_6.php

$response = null;
if ($_POST) {
  $params = [];
  foreach($_POST['key'] as $i=>$key) {
    if (!empty($key) && array_key_exists($i, $_POST['value'])) {
        $params = "$key=" . urlencode($_POST['value'][$i]);
    }
  }
  $options = array('http' =>
    array(
      'method'  => $_POST['method'],
      'content' => implode("&", $params)
    )
  );
  $context = stream_context_create($options);
  $response = file_get_contents($_POST['url'], false, $context);
  switch ($_POST['response']) {
    case 0 :
      $json = json_decode($response, true);
      $response_text = json_encode($json, JSON_PRETTY_PRINT);
      break;
    case 1:
      $dom = dom_import_simplexml($response)->ownerDocument;
      $dom->formatOutput = true;
      $response_text = $dom->saveXML();
      break;
  }
}
echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
<script src="https://code.jquery.com/jquery-1.12.2.min.js"
        integrity="sha256-lZFHibXzMHo3GGeehn1hudTAP3Sc0uKXBXAzHX1sjtk="
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"
        integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
        crossorigin="anonymous"></script>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7"
      crossorigin="anonymous">
<script>
function AddParameter() {
  var \$params = $('#parameters');
  if (\$params) {
    var \$div = \$('<div>');
    \$div.html(\$params.html());
    \$div.insertAfter(\$params);
  }
}
echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
<script src="https://code.jquery.com/jquery-1.12.2.min.js"
        integrity="sha256-lZFHibXzMHo3GGeehn1hudTAP3Sc0uKXBXAzHX1sjtk="
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"
        integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
        crossorigin="anonymous"></script>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7"
      crossorigin="anonymous">
<script>
function AddParameter() {
  var \$params = \$('#parameters');
  if (\$params) {
    var \$div = \$('<div>');
    \$div.html(\$params.html());
    \$div.insertAfter(\$params);
  }
}
</script>
</head>
<body>
<form name="api" method="POST" action="{$_SERVER['PHP_SELF']}">
<div>
  <lable>API Endpoint</label>
  <input class="form-control" type="text" name="url" />
</div>
<div>
  <lable>Method</label>
  <select class="form-control" name="method">
    <option value="GET">GET</option>
    <option value="POST">POST</option>
  </select>
</div>
<div>
  <lable>Response</label>
  <select class="form-control" name="response">
    <option value="0">JSON</option>
    <option value="1">XML</option>
  </select>
</div>
<div id="parameters">
<div id="parameters">
  <lable>Parameters</label>
  <div style="width:30%; display: inline-block">
    <input class="form-control" type="text" name="key[]" />
  </div>
  <div style="width:50%; display: inline-block">
    <input class="form-control" type="text" name="value[]" />
  </div>
</div>
</form>
<button onclick="AddParameter()">Add Parameters</button>
<button onclick="document.api.submit()">Submit</button>
<pre id="response">
$response_text
</pre>
</body>
</html>
HEREDOC;
