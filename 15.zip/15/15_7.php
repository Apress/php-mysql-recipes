<?php
// 15_7.php

require "api_credentials.inc";

$params = [
  "appkey=$appkey",
  "article=1"
];
$hash = hash('sha256', implode("", $params) . $secret);
$params['hash'] = $hash;

$options = array('http' =>
  array(
    'method'  => "POST",
    'content' => implode("&", $params)
  )
);
$context = stream_context_create($options);
$response = file_get_contents("http://example.com/articels", false, $context);
