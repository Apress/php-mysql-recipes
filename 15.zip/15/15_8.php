<?php
// 16_8.php

$params = [
  "appkey={$_POST['appkey']}",
  "article={$_POST['article']}"
];
$secret = GetSecret($_POST['appkey']);
$hash = hash('sha256', implode("", $params) . $secret);
if ($hash == $_POST['hash']) {
  // Request is allowed
}
else {
  // Error – the hash did not match
