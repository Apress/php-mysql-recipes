<?php
// 16_1.php
$con = mysqli_connect('127.0.0.1', 'php', 'secret', 'music');
if (mysqli_connect_error()) {
  die("Error connecting: " . mysqli_connect_errno() . ' '
      . mysqli_connect_error() . "\n");
}
else {
  echo "Connected to music\n";
}
