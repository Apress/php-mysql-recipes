<?php
// 16_10.php

class music extends mysqli {
  private $schema = [];

  function __construct() {
    parent::__construct('127.0.0.1', 'php', 'secret', 'music');
    if ($this->connect_error) {
      die("Unable to connect to music\n");
    }
    $sql = "select table_name from information_schema.tables where table_schema='music';";
    $rs = $this->Query($sql);
    while ($table = $rs->fetch_assoc()) {
      $sql = "select column_name, column_type from information_schema.columns where table_name='{$table['table_name']}';";
      $rs1 = $this->query($sql);
      while($col = $rs1->fetch_assoc()) {
        $this->schema[$table['table_name']][$col['column_name']] = $col['column_type'];
      }
      $rs1->close();
    }
    $rs->close();
    print_r($this->schema);
  }
}

$music = new music();
