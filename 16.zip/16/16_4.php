<?php
// 16_4.php
$mysqli = new mysqli('127.0.0.1', 'php', 'secret', 'music');
if ($mysqli->connect_error) {
  die("Error connecting: {$mysqli->connect_errno} {$mysqli->connect_error}\n");
}
else {
  echo "Connected to music\n";
  $mysqli->close();
}
