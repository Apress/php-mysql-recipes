<?php
// 16_6.php

ini_set('display_errors', 1);

class music extends mysqli {
  function __construct() {
    parent::__construct('127.0.0.1', 'php', 'secret', 'music');
    if ($this->connect_error) {
      die("Unable to connect to music\n");
    }
  }

  function getAlbums() {
    $albums = [];
    $result = $this->Query("select * from album;");
    if ($result) {
      while($row = $result->fetch_assoc()) {
        $albums[] = $row;
      }
      $result->close();
    }
    return $albums;
  }
}

$music = new music();

print_r($music->getAlbums());
