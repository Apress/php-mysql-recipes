<?php
// 16_7.php

ini_set('display_errors', 1);

class music extends mysqli {
  function __construct() {
    parent::__construct('127.0.0.1', 'php', 'secret', 'music');
    if ($this->connect_error) {
      die("Unable to connect to music\n");
    }
  }

  function addAlbum($title, $description = null) {
    $t = $this->real_escape_string($title);
    if ($description) {
      $d = $this->real_escape_string($description);
      $sql = "insert into album (title, description) values ('$t', '$d')";
    }
    else {
      $sql = "insert into album (title) values ('$t')";
    }
    $this->Query($sql);
    return $this->insert_id;
  }

  function getAlbums() {
    $albums = [];
    $result = $this->Query("select * from album;");
    if ($result) {
      while($row = $result->fetch_assoc()) {
        $albums[] = $row;
      }
      $result->close();
    }
    return $albums;
  }
}

$music = new music();
$music->addAlbum("Let It Be");
$music->addAlbum("Twist and Shout");

print_r($music->getAlbums());
