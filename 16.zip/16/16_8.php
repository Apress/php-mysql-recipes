<?php
// 16_8.php

ini_set('display_errors', 1);

class music extends mysqli {
  function __construct() {
    parent::__construct('127.0.0.1', 'php', 'secret', 'music');
    if ($this->connect_error) {
      die("Unable to connect to music\n");
    }
  }

  function addArtist($name, $description = null) {
    $n = $this->real_escape_string($name);
    if ($description) {
      $d = $this->real_escape_string($description);
      $sql = "insert into artist (artist_name, description) values ('$n', '$d')";
    }
    else {
      $sql = "insert into artist (artist_name) values ('$n')";
    }
    $this->Query($sql);
    return $this->insert_id;
  }

  function getArtists() {
    $artists = [];
    $sql = "select * from artist";
    $result = $this->Query($sql);
    if ($result) {
      while($row = $result->fetch_assoc()) {
        $artists[] = $row;
      }
      $result->close();
    }
    return $artists;
  }

  function addAlbum($title, $artist_id = null, $description = null) {
    if (is_null($artist_is)) {
      $id = "NULL";
    }
    else {
      $id = (int)$artist_id;
    }
    $t = $this->real_escape_string($title);
    if ($description) {
      $d = $this->real_escape_string($description);
      $sql = "insert into album (title, artist_id, description) values ('$t', $id, '$d')";
    }
    else {
      $sql = "insert into album (title, artist_id) values ('$t', $id)";
    }
    $this->Query($sql);
    return $this->insert_id;
  }

  function getAlbums($artist_id = null) {
    $albums = [];
    if ($artist_id) {
      $sql = "select album.id, artist_id, artist_name, title from album, artist where album.artist_id=artist.id and artist_id=$artist_id";
    }
    else {
      $sql = "select album.id, artist_id, artist_name, title from album left outer join artist on (album.artist_id=artist.id)";
    }
    $result = $this->Query($sql);
    if ($result) {
      while($row = $result->fetch_assoc()) {
        $albums[] = $row;
      }
      $result->close();
    }
    return $albums;
  }
}

$music = new music();
$id = $music->addArtist("Pink Floyd");
$music->addAlbum("The Dark Side Of The Moon", $id);
$music->addAlbum("The Wall", $id);
$music->addAlbum("Widh You Were Here", $id);

print_r($music->getArtists());
print_r($music->getAlbums(1));
print_r($music->getAlbums(2));
print_r($music->getAlbums());
