<?php
// 16_9.php

class music extends mysqli {
  private $schema = [
    'artist' => [
      'id' => 'int',
      'artist_name' => 'char',
      'description' => 'char',
    ],
    'album' => [
      'id' => 'int',
      'title' => 'char',
      'artist_id' => 'int',
      'description' => 'char',
    ]
  ];

  function __construct() {
    parent::__construct('127.0.0.1', 'php', 'secret', 'music');
    if ($this->connect_error) {
      die("Unable to connect to music\n");
    }
  }

  function insertRow($table, $schema, $data = []) {
    $columns = [];
    $values = [];
    foreach($data as $k => $v) {
      if (array_key_exists($k, $schema)) {
        $columns[] = $k;
        if (is_null($v)) {
			$values[] = "NULL";
        }
        else {
          switch($schema[$k]) {
            case 'int' :
              $values[] = (int)$v;
              break;
            case 'char' :
              $values[] = "'" . $this->real_escape_string($v) . "'";
              break;
          }
        }
      }
    }
    if (sizeof($columns)) {
      $sql = "insert into $table (" . implode(", ", $columns) . ") values (" .
              implode(", ", $values) . ");";
      $this->Query($sql);
      return $this->insert_id;
    }
    else {
      return false;
    }
  }

  function addArtist($name, $description = null) {
    return $this->insertRow(
      'artist', $this->schema['artist'], [
        'artist_name' => $name,
        'description' => $description
      ]
    );
  }

  function addAlbum($title, $artist_id, $description = null) {
    return $this->insertRow(
      'album', $this->schema['album'], [
        'title' => $title,
        'artist_id' => $artist_id,
        'description' => $description
      ]
    );
  }

  private function updateRow($table, $schema, $id, $data) {
    $columns = [];
    foreach($data as $k => $v) {
      if (array_key_exists($k, $schema)) {
        if (is_null($v)) {
          $column[] = "$k = NULL";
        }
        else {
          switch($schema[$k]) {
            case 'int' :
              $column[] = "$k = " . (int)$v;
              break;
            case 'char' :
              $column[] = "$k = '" . $this->real_escape_string($v) ."'";
              break;
          }
        }
      }
    }
    if (sizeof($columns)) {
      $sql = "update $table set " . implode(", ", $columns) .
             " where id = $id;";
      $this->Query($sql);
    }
  }

  function updateArtist($id, $data = []) {
    $this->update("artist", $this->schema['artist'], $id, $data);
  }

  function updateAlbum($id, $data = []) {
    $this->update("album", $this->schema['album'], $id, $data);
  }

  private function deleteRow($table, $id) {
    $sql = "delete from $table where id = " . (int)$id . ";";
    $this->Query($sql);
  }

  function deleteArtist($id) {
    $sql = "update album set artist_id=NULL where id = " . (int)$id . ";";
    $this->Query($sql);
    $this->deleteRow("artist", $id);
  }

  function deleteAlbum($id) {
    $this->deleteRow("album", $id);
  }

  function getArtists() {
    $artists = [];
    $sql = "select * from artist";
    $result = $this->Query($sql);
    if ($result) {
      while($row = $result->fetch_assoc()) {
        $artists[] = $row;
      }
      $result->close();
    }
    return $artists;
  }

  function getAlbums($artist_id = null) {
    $albums = [];
    if ($artist_id) {
      $sql = "select album.id, artist_id, artist_name, title from album, artist where album.artist_id=artist.id and artist_id=$artist_id";
    }
    else {
      $sql = "select album.id, artist_id, artist_name, title from album left outer join artist on (album.artist_id=artist.id)";
    }
    $result = $this->Query($sql);
    if ($result) {
      while($row = $result->fetch_assoc()) {
        $albums[] = $row;
      }
      $result->close();
    }
    return $albums;
  }
}
